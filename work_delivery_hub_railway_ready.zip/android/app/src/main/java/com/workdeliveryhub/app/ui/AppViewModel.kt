package com.workdeliveryhub.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.workdeliveryhub.app.data.*
import com.workdeliveryhub.app.location.LocationProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MultipartBody

sealed interface UiState { data object Idle: UiState; data object Loading: UiState; data class Error(val message:String): UiState; data object Done: UiState }
class AppViewModel: ViewModel() {
    init { if (ApiClient.token != null) viewModelScope.launch { runCatching{ApiClient.api.me()}.onSuccess{_user.value=it}; loadAll() } }
    private val _user = MutableStateFlow<UserDto?>(null); val user = _user.asStateFlow()
    private val _companies = MutableStateFlow<List<CompanyDto>>(emptyList()); val companies = _companies.asStateFlow()
    private val _jobs = MutableStateFlow<List<JobDto>>(emptyList()); val jobs = _jobs.asStateFlow()
    private val _orders = MutableStateFlow<List<OrderDto>>(emptyList()); val orders = _orders.asStateFlow()
    private val _companyOrders = MutableStateFlow<List<OrderDto>>(emptyList()); val companyOrders = _companyOrders.asStateFlow()
    private val _state = MutableStateFlow<UiState>(UiState.Idle); val state = _state.asStateFlow()
    fun login(username:String,password:String,onSuccess:()->Unit={}) = viewModelScope.launch { _state.value=UiState.Loading; runCatching { ApiClient.api.login(LoginRequest(username,password)) }.onSuccess { ApiClient.setToken(it.token); _user.value=it.user; loadAll(); onSuccess() }.onFailure { _state.value=UiState.Error(it.message ?: "Login failed") } }
    fun register(fields: Map<String,String>, idBytes: ByteArray, idName: String, idMime: String, photoBytes: ByteArray, photoName: String, photoMime: String, onSuccess: () -> Unit = {}) = viewModelScope.launch {
        _state.value=UiState.Loading
        val parts=fields.mapValues { it.value.toRequestBody("text/plain".toMediaType()) }
        val idPart=MultipartBody.Part.createFormData("idDocument", idName, idBytes.toRequestBody(idMime.toMediaType()))
        val photoPart=MultipartBody.Part.createFormData("profilePhoto", photoName, photoBytes.toRequestBody(photoMime.toMediaType()))
        runCatching{ApiClient.api.register(parts,idPart,photoPart)}.onSuccess{ ApiClient.setToken(it.token); _user.value=it.user; _state.value=UiState.Done; loadAll(); onSuccess() }.onFailure{_state.value=UiState.Error(it.message ?: "Registration failed")}
    }
    fun logout(onDone: () -> Unit = {}) = viewModelScope.launch { runCatching{ApiClient.api.logout()}; ApiClient.clearToken(); _user.value=null; _companies.value=emptyList(); _jobs.value=emptyList(); _orders.value=emptyList(); onDone() }
    fun loadTracking(orderId:Int) = viewModelScope.launch { runCatching{ApiClient.api.tracking(orderId)}.onSuccess { fresh -> _orders.value=_orders.value.map { if (it.id==fresh.id) fresh else it }.let { list -> if (list.none{it.id==fresh.id}) listOf(fresh)+list else list } } }
    fun loadAll() = viewModelScope.launch { runCatching { ApiClient.api.companies() }.onSuccess{_companies.value=it}; runCatching{ApiClient.api.jobs()}.onSuccess{_jobs.value=it}; runCatching{ApiClient.api.orders()}.onSuccess{_orders.value=it}; runCatching{ApiClient.api.companyOrders()}.onSuccess{_companyOrders.value=it}; _state.value=UiState.Done }
    fun placeOrder(req:CreateOrderRequest,onSuccess: (OrderDto)->Unit) = viewModelScope.launch { _state.value=UiState.Loading; runCatching{ApiClient.api.createOrder(req)}.onSuccess{_orders.value=listOf(it)+_orders.value; _state.value=UiState.Done; onSuccess(it)}.onFailure{_state.value=UiState.Error(it.message ?: "Could not place order")} }
    fun payMpesa(reference:String,phone:String,onSuccess:()->Unit={}) = viewModelScope.launch { _state.value=UiState.Loading; runCatching{ApiClient.api.payMpesa(PaymentRequest(reference,phone))}.onSuccess{_state.value=UiState.Done; onSuccess()}.onFailure{_state.value=UiState.Error(it.message ?: "M-Pesa payment failed")} }
    fun receive(orderId:Int,onSuccess:()->Unit={}) = viewModelScope.launch { runCatching{ApiClient.api.receive(orderId)}.onSuccess{loadAll();onSuccess()}.onFailure{_state.value=UiState.Error(it.message ?: "Could not confirm receipt")} }
    fun rate(orderId:Int,kind:String,score:Int,comment:String,onSuccess:()->Unit={}) = viewModelScope.launch { runCatching{ApiClient.api.rateOrder(orderId,RatingRequest(kind,score,comment))}.onSuccess{onSuccess()}.onFailure{_state.value=UiState.Error(it.message ?: "Rating failed")} }

    fun updateCompanyOrder(orderId:Int,status:String,onSuccess:()->Unit={}) = viewModelScope.launch { runCatching{ApiClient.api.companyUpdateOrder(mapOf("orderId" to orderId,"status" to status))}.onSuccess{loadAll(); onSuccess()}.onFailure{_state.value=UiState.Error(it.message ?: "Could not update order")} }
    fun acceptDelivery(id:Int, location:LocationRequest, onSuccess:()->Unit={}) = viewModelScope.launch { runCatching{ApiClient.api.acceptDelivery(id,location)}.onSuccess{loadAll();onSuccess()}.onFailure{_state.value=UiState.Error(it.message ?: "Could not accept delivery")} }
    fun updateRiderLocation(location:LocationRequest) = viewModelScope.launch { runCatching{ApiClient.api.riderLocation(location)} }
    fun bid(id:Int,amount:String,message:String) = viewModelScope.launch { runCatching{ApiClient.api.bid(id,BidRequest(amount,message))}.onSuccess{_state.value=UiState.Done}.onFailure{_state.value=UiState.Error(it.message ?: "Bid failed")} }
}
