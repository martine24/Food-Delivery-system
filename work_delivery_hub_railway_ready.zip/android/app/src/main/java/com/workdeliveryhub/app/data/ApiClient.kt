package com.workdeliveryhub.app.data

import android.content.Context
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiClient {
    // Override with -PAPI_BASE_URL=https://your-domain/ for release builds.
    val BASE_URL: String get() = BuildConfig.API_BASE_URL
    private var prefs: android.content.SharedPreferences? = null
    @Volatile var token: String? = null
        private set
    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences("hub_auth", Context.MODE_PRIVATE)
        token = prefs?.getString("token", null)
    }
    fun setToken(value: String?) { token = value; prefs?.edit()?.putString("token", value)?.apply() }
    fun clearToken() { token = null; prefs?.edit()?.remove("token")?.apply() }
    private val auth = Interceptor { chain ->
        val b = chain.request().newBuilder()
        token?.let { b.addHeader("Authorization", "Token $it") }
        chain.proceed(b.build())
    }
    private val client = OkHttpClient.Builder().addInterceptor(auth).addInterceptor(HttpLoggingInterceptor().apply { level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE }).build()
    val api: HubApi = Retrofit.Builder().baseUrl(BASE_URL).client(client).addConverterFactory(GsonConverterFactory.create()).build().create(HubApi::class.java)
}
