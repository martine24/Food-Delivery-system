package com.workdeliveryhub.app.data

import retrofit2.http.*
import okhttp3.MultipartBody
import okhttp3.RequestBody

data class UserDto(val id: Int, val name: String, val role: String, val phone: String, val town: String, val verified: Boolean)
data class LoginRequest(val username: String, val password: String)
data class LoginResponse(val token: String, val user: UserDto)
data class RegistrationResponse(val token: String, val user: UserDto)
data class CompanyDto(val id: Int, val name: String, val description: String?, val address: String?, val logoUrl: String?, val dishes: List<MenuItemDto> = emptyList())
data class MenuItemDto(val id: Int, val name: String, val description: String?, val price: String, val imageUrl: String?, val available: Boolean)
data class OrderItemRequest(val menuItemId: Int, val quantity: Int)
data class CreateOrderRequest(val companyId: Int, val deliveryAddress: String, val deliveryPhone: String, val latitude: Double, val longitude: Double, val notes: String, val items: List<OrderItemRequest>)
data class OrderDto(val id: Int, val companyName: String, val status: String, val subtotal: String, val platformFee: String, val total: String, val deliveryAddress: String, val deliveryLat: Double?, val deliveryLng: Double?, val riderName: String?, val riderLat: Double?, val riderLng: Double?)
data class JobDto(val id: Int, val title: String, val description: String, val location: String, val online: Boolean, val amount: String, val status: String, val posterName: String)
data class BidRequest(val amount: String, val message: String)
data class LocationRequest(val latitude: Double, val longitude: Double)
data class PaymentRequest(val transactionReference: String, val phone: String)
data class RatingRequest(val kind: String, val score: Int, val comment: String = "")
data class GenericResponse(val success: Boolean, val message: String, val reference: String? = null)
data class PaymentStatusDto(val reference: String, val status: String, val payoutStatus: String, val paidAt: String?, val orderId: Int?, val jobId: Int?)
data class NotificationDto(val id: Int, val title: String, val message: String, val channel: String, val read: Boolean, val created_at: String, val metadata: Map<String, Any>?)

interface HubApi {
    @POST("api/v1/auth/login/") suspend fun login(@Body body: LoginRequest): LoginResponse
    @Multipart @POST("api/v1/auth/register/") suspend fun register(@PartMap fields: Map<String, @JvmSuppressWildcards RequestBody>, @Part idDocument: MultipartBody.Part, @Part profilePhoto: MultipartBody.Part): RegistrationResponse
    @POST("api/v1/auth/logout/") suspend fun logout(): GenericResponse
    @GET("api/v1/me/") suspend fun me(): UserDto
    @GET("api/v1/companies/") suspend fun companies(): List<CompanyDto>
    @POST("api/v1/orders/") suspend fun createOrder(@Body body: CreateOrderRequest): OrderDto
    @GET("api/v1/orders/") suspend fun orders(): List<OrderDto>
    @GET("api/v1/jobs/") suspend fun jobs(): List<JobDto>
    @POST("api/v1/jobs/{id}/bid/") suspend fun bid(@Path("id") id: Int, @Body body: BidRequest): GenericResponse
    @GET("api/v1/rider/orders/") suspend fun riderOrders(): List<OrderDto>
    @POST("api/v1/rider/orders/{id}/accept/") suspend fun acceptDelivery(@Path("id") id: Int, @Body body: LocationRequest): GenericResponse
    @POST("api/v1/rider/location/") suspend fun riderLocation(@Body body: LocationRequest): GenericResponse
    @GET("api/v1/orders/{id}/tracking/") suspend fun tracking(@Path("id") id: Int): OrderDto
    @POST("api/v1/payments/mpesa/") suspend fun payMpesa(@Body body: PaymentRequest): GenericResponse
    @GET("api/v1/payments/{reference}/") suspend fun paymentStatus(@Path("reference") reference: String): PaymentStatusDto
    @GET("api/v1/company/orders/") suspend fun companyOrders(): List<OrderDto>
    @POST("api/v1/company/orders/") suspend fun companyUpdateOrder(@Body body: Map<String, Any>): OrderDto
    @GET("api/v1/notifications/") suspend fun notifications(): List<NotificationDto>
    @POST("api/v1/orders/{id}/receive/") suspend fun receive(@Path("id") id: Int): GenericResponse
    @POST("api/v1/orders/{id}/rating/") suspend fun rateOrder(@Path("id") id: Int, @Body body: RatingRequest): GenericResponse
}
