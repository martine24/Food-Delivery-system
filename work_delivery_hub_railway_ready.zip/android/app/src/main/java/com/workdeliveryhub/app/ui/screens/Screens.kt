package com.workdeliveryhub.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.workdeliveryhub.app.data.*
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.android.gms.maps.model.CameraPosition
import com.workdeliveryhub.app.location.LocationProvider
import com.workdeliveryhub.app.ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) { delay(1300); onDone() }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(HubBlueDark, HubBlue))), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(92.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.LocationOn, null, tint = HubBlue, modifier = Modifier.size(58.dp))
            }
            Spacer(Modifier.height(20.dp))
            Text("Work & Delivery Hub", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("Food • Jobs • Deliveries • More", color = Color.White.copy(.85f), fontSize = 14.sp)
        }
    }
}

@Composable
private fun AppTopBar(title: String, onBack: (() -> Unit)? = null, action: @Composable (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
        else Box(Modifier.size(42.dp).clip(CircleShape).background(HubBlue), contentAlignment = Alignment.Center) { Icon(Icons.Default.LocationOn, null, tint = Color.White) }
        Spacer(Modifier.width(10.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        action?.invoke()
    }
}

@Composable
private fun BottomNav(selected: String, onSelect: (String) -> Unit) {
    NavigationBar(containerColor = Color.White) {
        listOf("home" to Icons.Default.Home, "food" to Icons.Default.Restaurant, "jobs" to Icons.Default.Work, "orders" to Icons.Default.ReceiptLong, "profile" to Icons.Default.Person).forEach { (key, icon) ->
            NavigationBarItem(selected = selected == key, onClick = { onSelect(key) }, icon = { Icon(icon, null) }, label = { Text(key.replaceFirstChar { it.uppercase() }) })
        }
    }
}

@Composable
fun LoginScreen(vm: AppViewModel, onSuccess: () -> Unit, onRegister: () -> Unit, onBack: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(HubBackground)) {
        AppTopBar("Sign in", onBack)
        LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(76.dp).clip(CircleShape).background(HubBlue), contentAlignment = Alignment.Center) { Icon(Icons.Default.LocationOn, null, tint = Color.White, modifier = Modifier.size(46.dp)) }
                    Spacer(Modifier.height(16.dp)); Text("Welcome Back", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold); Text("Sign in to your Work & Delivery Hub account", color = HubMuted)
                }
            }
            item { OutlinedTextField(username, { username = it }, label = { Text("Email or Phone Number") }, leadingIcon = { Icon(Icons.Default.Person, null) }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item { OutlinedTextField(password, { password = it }, label = { Text("Password") }, leadingIcon = { Icon(Icons.Default.Lock, null) }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item { Button(onClick = { vm.login(username, password, onSuccess) }, enabled = username.isNotBlank() && password.isNotBlank(), modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) { Text("Login", fontWeight = FontWeight.Bold) } }
            item { Row(verticalAlignment = Alignment.CenterVertically) { HorizontalDivider(Modifier.weight(1f)); Text("  or  ", color = HubMuted); HorizontalDivider(Modifier.weight(1f)) } }
            item { OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.AccountCircle, null); Spacer(Modifier.width(8.dp)); Text("Continue with Google") } }
            item { OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.PhoneAndroid, null); Spacer(Modifier.width(8.dp)); Text("Continue with M-Pesa") } }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Text("Don't have an account? "); Text("Register", color = HubBlue, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onRegister)) } }
            item { if (vm.state.collectAsState().value is UiState.Error) Text((vm.state.collectAsState().value as UiState.Error).message, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
fun RegisterScreen(vm: AppViewModel, onSuccess: () -> Unit, onBack: () -> Unit) {
    var role by remember { mutableStateOf("CUSTOMER") }; var username by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var town by remember { mutableStateOf("") }; var idNumber by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var vehicle by remember { mutableStateOf("Bike") }; var idBytes by remember { mutableStateOf<ByteArray?>(null) }; var idName by remember { mutableStateOf("id.jpg") }; var idMime by remember { mutableStateOf("image/jpeg") }; var photoBytes by remember { mutableStateOf<ByteArray?>(null) }; var photoName by remember { mutableStateOf("profile.jpg") }; var photoMime by remember { mutableStateOf("image/jpeg") }
    val context=LocalContext.current
    val idPicker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { context.contentResolver.openInputStream(it)?.use { input -> idBytes=input.readBytes() }; idName=it.lastPathSegment ?: "id.jpg"; idMime=context.contentResolver.getType(it) ?: "application/octet-stream" } }
    val photoPicker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { context.contentResolver.openInputStream(it)?.use { input -> photoBytes=input.readBytes() }; photoName=it.lastPathSegment ?: "profile.jpg"; photoMime=context.contentResolver.getType(it) ?: "image/jpeg" } }
    Column(Modifier.fillMaxSize().background(HubBackground)) {
        AppTopBar("Create account", onBack)
        LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("Join Work & Delivery Hub", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold); Text("Identity verification is required before marketplace activity.", color = HubMuted) }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("CUSTOMER" to "Customer", "RIDER" to "Rider", "COMPANY" to "Company").forEach { (v,l) -> FilterChip(selected = role == v, onClick = { role=v }, label={Text(l)}) } } }
            item { OutlinedTextField(username,{username=it},label={Text("Username")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
            item { OutlinedTextField(name,{name=it},label={Text("Full name / business name")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
            item { OutlinedTextField(phone,{phone=it},label={Text("Phone number")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
            item { OutlinedTextField(town,{town=it},label={Text("Town / Location")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
            item { OutlinedTextField(idNumber,{idNumber=it},label={Text("National ID / ID number")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
            item { OutlinedTextField(password,{password=it},label={Text("Password (10+ characters)")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth(),singleLine=true) }
            if(role=="RIDER") item { OutlinedTextField(vehicle,{vehicle=it},label={Text("Vehicle type")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
            item { Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp)) { Text("Identity documents",fontWeight=FontWeight.Bold); Text(if(idBytes!=null) "ID document selected" else "ID document required",color=HubMuted); Spacer(Modifier.height(8.dp)); OutlinedButton(onClick={idPicker.launch("*/*")},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.UploadFile,null);Spacer(Modifier.width(8.dp));Text("Choose ID document")} } } }
            item { Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp)) { Text("Profile photo",fontWeight=FontWeight.Bold); Text(if(photoBytes!=null) "Profile photo selected" else "Profile photo required",color=HubMuted); Spacer(Modifier.height(8.dp)); OutlinedButton(onClick={photoPicker.launch("image/*")},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.CameraAlt,null);Spacer(Modifier.width(8.dp));Text("Choose profile photo")} } } }
            item { Button(onClick={ val cleanName=name.trim(); val fields=mapOf("username" to username,"password" to password,"phone" to phone,"town" to town,"townLocation" to town,"idNumber" to idNumber,"role" to role,"firstName" to cleanName,"vehicleType" to vehicle,"businessName" to cleanName,"address" to town); val ib=idBytes; val pb=photoBytes; if(ib!=null && pb!=null) vm.register(fields,ib,idName,idMime,pb,photoName,photoMime,onSuccess) }, enabled=username.isNotBlank()&&name.isNotBlank()&&phone.isNotBlank()&&town.isNotBlank()&&idNumber.isNotBlank()&&password.length>=10&&idBytes!=null&&photoBytes!=null,modifier=Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(14.dp)){Text("Create Account",fontWeight=FontWeight.Bold)} }
            item { val st=vm.state.collectAsState().value; if(st is UiState.Error) Text(st.message,color=MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
fun HomeScreen(vm: AppViewModel, onLogin: () -> Unit, onRegister: () -> Unit, onJobs: () -> Unit, onOrder: (CompanyDto) -> Unit, onProfile: () -> Unit) {
    var selected by remember { mutableStateOf("home") }
    Scaffold(bottomBar = { BottomNav(selected) { key -> selected = key; if (key == "jobs") onJobs(); if (key == "profile") onProfile() } }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).background(HubBackground), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(HubBlue), contentAlignment = Alignment.Center) { Icon(Icons.Default.LocationOn, null, tint = Color.White) }
                    Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text("Work & Delivery Hub", fontWeight = FontWeight.ExtraBold); Text("Nairobi, Kenya", color = HubMuted, style = MaterialTheme.typography.bodySmall) }
                    IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, "Notifications") }
                }
            }
            item { Card(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = HubBlue)) { Column(Modifier.padding(20.dp)) { Text("Good Food\nFast Delivery\nGreat Service", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(16.dp)); OutlinedTextField("", {}, placeholder = { Text("Search for food, jobs, or services") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color.White, focusedContainerColor = Color.White, unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent)) } } }
            item { LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { listOf("Food" to Icons.Default.Restaurant, "Jobs" to Icons.Default.Work, "Deliveries" to Icons.Default.LocalShipping, "More" to Icons.Default.GridView).forEach { (label, icon) -> FeatureTile(label, icon) } } }
            item { SectionTitle("Featured Restaurants", "See All") }
            items(vm.companies.value) { c -> RestaurantCard(c) { onOrder(c) } }
            if (vm.companies.value.isEmpty()) item { EmptyCard("Restaurants will appear here once your API is connected.") }
            item { SectionTitle("Featured Jobs", "View All") }
            items(vm.jobs.value.take(4)) { j -> JobCard(j, onClick = onJobs) }
            if (vm.jobs.value.isEmpty()) item { EmptyCard("Fresh local and remote jobs will appear here.") }
            item { WhyHubCard() }
            item { AppDownloadCard() }
            item { if (ApiClient.token == null) Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { Button(onClick = onLogin, Modifier.weight(1f)) { Text("Login") }; OutlinedButton(onClick = onRegister, Modifier.weight(1f)) { Text("Sign Up") } } }
        }
    }
}

@Composable private fun FeatureTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector) { Card(Modifier.width(92.dp), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(42.dp).clip(CircleShape).background(HubBlue.copy(.1f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = HubBlue) }; Spacer(Modifier.height(6.dp)); Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp) } } }
@Composable private fun SectionTitle(title: String, action: String) { Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f)); Text(action, color = HubBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp) } }
@Composable private fun RestaurantCard(c: CompanyDto, onClick: () -> Unit) { Card(Modifier.padding(horizontal = 18.dp).fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp)) { Column { val image = c.dishes.firstOrNull()?.imageUrl; if (!image.isNullOrBlank()) AsyncImage(image, null, Modifier.fillMaxWidth().height(130.dp), contentScale = ContentScale.Crop) else Box(Modifier.fillMaxWidth().height(110.dp).background(Brush.linearGradient(listOf(HubBlueDark, HubBlue))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Restaurant, null, tint = Color.White, modifier = Modifier.size(48.dp)) }; Column(Modifier.padding(14.dp)) { Text(c.name, fontWeight = FontWeight.ExtraBold); Text(c.address ?: "Nairobi", color = HubMuted, style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(6.dp)); Text("★ 4.7  •  20–35 min  •  KSh 150 delivery", color = HubMuted, fontSize = 12.sp); Spacer(Modifier.height(10.dp)); Button(onClick = onClick, Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)) { Text("Order Now") } } } } }
@Composable private fun JobCard(j: JobDto, onClick: () -> Unit) { Card(Modifier.padding(horizontal = 18.dp).fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(HubPurple.copy(.12f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Work, null, tint = HubPurple) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(j.title, fontWeight = FontWeight.ExtraBold); Text(if (j.online) "Remote" else j.location, color = HubMuted, fontSize = 12.sp) }; Text("KSh ${j.amount}", color = HubBlue, fontWeight = FontWeight.Bold) }; Spacer(Modifier.height(8.dp)); Text(j.description, maxLines = 2, color = HubMuted); Spacer(Modifier.height(10.dp)); Button(onClick = onClick, Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)) { Text("Apply Now") } } } }
@Composable private fun WhyHubCard() { Card(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(18.dp)) { Text("Why Choose Work & Delivery Hub?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold); listOf("Safe & Secure" to Icons.Default.Security, "Fast & Reliable" to Icons.Default.Bolt, "Quality Services" to Icons.Default.Star, "24/7 Support" to Icons.Default.SupportAgent).forEach { (t, i) -> Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(38.dp).clip(CircleShape).background(HubBlue), contentAlignment = Alignment.Center) { Icon(i, null, tint = Color.White) }; Spacer(Modifier.width(12.dp)); Text(t, fontWeight = FontWeight.Bold) } } } } }
@Composable private fun AppDownloadCard() { Card(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = HubBlue)) { Column(Modifier.padding(20.dp)) { Text("Get the App Today", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold); Text("Fast • Secure • Reliable", color = Color.White.copy(.8f)); Spacer(Modifier.height(12.dp)); Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = HubBlue)) { Text("Download App") } } } }
@Composable private fun EmptyCard(text: String) { Card(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text(text, Modifier.padding(18.dp), color = HubMuted) } }

@Composable
fun DashboardScreen(vm: AppViewModel, onOrder: (CompanyDto) -> Unit, onTracking: (Int) -> Unit, onJobs: () -> Unit, onProfile: () -> Unit) {
    HomeScreen(vm, {}, {}, onJobs, onOrder, onProfile)
}

@Composable
fun OrderScreen(company: CompanyDto, vm: AppViewModel, onDone: (OrderDto) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current; val location = remember { LocationProvider(context) }; val scope = rememberCoroutineScope(); var lat by remember { mutableStateOf<Double?>(null) }; var lng by remember { mutableStateOf<Double?>(null) }; var address by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }; val quantities = remember { mutableStateMapOf<Int, Int>() }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) scope.launch { location.current()?.let { p -> lat = p.latitude; lng = p.longitude } } }
    LaunchedEffect(Unit) { if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) scope.launch { location.current()?.let { p -> lat = p.latitude; lng = p.longitude } } else launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
    Column(Modifier.fillMaxSize().background(HubBackground)) {
        AppTopBar(company.name, onBack)
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Column(Modifier.padding(horizontal = 18.dp)) { Text("Choose your meal", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold); Text("Fresh food from ${company.name}", color = HubMuted) } }
            items(company.dishes) { d -> val q = quantities[d.id] ?: 0; Card(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { if (!d.imageUrl.isNullOrBlank()) AsyncImage(d.imageUrl, null, Modifier.size(78.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop) else Box(Modifier.size(78.dp).clip(RoundedCornerShape(12.dp)).background(HubBlue.copy(.08f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Restaurant, null, tint = HubBlue) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(d.name, fontWeight = FontWeight.ExtraBold); Text(d.description.orEmpty(), maxLines = 2, color = HubMuted, fontSize = 12.sp); Text("KSh ${d.price}", color = HubBlue, fontWeight = FontWeight.Bold) }; Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { quantities[d.id] = (q - 1).coerceAtLeast(0) }) { Icon(Icons.Default.Remove, null) }; Text(q.toString(), fontWeight = FontWeight.Bold); IconButton(onClick = { quantities[d.id] = (q + 1).coerceAtMost(99) }) { Icon(Icons.Default.Add, null) } } } } }
            item { Card(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = if (lat != null) Color(0xFFEAF8F2) else Color(0xFFFFF1F0))) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.MyLocation, null, tint = if (lat != null) HubGreen else MaterialTheme.colorScheme.error); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(if (lat != null) "GPS location captured" else "GPS is required to place an order", fontWeight = FontWeight.Bold); if (lat != null) Text("%.5f, %.5f".format(lat, lng), color = HubMuted, fontSize = 12.sp) }; if (lat == null) TextButton(onClick = { launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION) }) { Text("Enable") } } } }
            item { Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { OutlinedTextField(address, { address = it }, label = { Text("Delivery address") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(phone, { phone = it }, label = { Text("Delivery phone") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(notes, { notes = it }, label = { Text("Additional comments") }, modifier = Modifier.fillMaxWidth(), minLines = 3) } }
            item { Button(enabled = lat != null && lng != null && address.isNotBlank() && quantities.values.any { it > 0 }, onClick = { vm.placeOrder(CreateOrderRequest(company.id, address, phone, lat!!, lng!!, notes, quantities.filterValues { it > 0 }.map { OrderItemRequest(it.key, it.value) }), onDone) }, modifier = Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) { Text("Continue to payment", fontWeight = FontWeight.Bold) } }
        }
    }
}

@Composable
fun PaymentScreen(order: OrderDto, vm: AppViewModel, onPaid: () -> Unit, onBack: () -> Unit) {
    var phone by remember { mutableStateOf("") }; var waiting by remember { mutableStateOf(false) }; var message by remember { mutableStateOf("") }
    val reference=order.transactionReference
    LaunchedEffect(waiting, reference) {
        if (waiting && !reference.isNullOrBlank()) {
            while (true) {
                val result=runCatching { ApiClient.api.paymentStatus(reference) }.getOrNull()
                when(result?.status) { "PAID" -> { waiting=false; onPaid(); break }; "FAILED","REFUNDED" -> { waiting=false; message="Payment was not completed."; break } }
                delay(3000)
            }
        }
    }
    Column(Modifier.fillMaxSize().background(HubBackground)) { AppTopBar("Payment", onBack); LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) { Text("Order Summary", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold); Text(order.companyName, color = HubMuted); Spacer(Modifier.height(12.dp)); SummaryRow("Items", "KSh ${order.subtotal}"); SummaryRow("Platform Fee", "KSh ${order.platformFee}"); HorizontalDivider(Modifier.padding(vertical = 8.dp)); SummaryRow("Total", "KSh ${order.total}", true) } } }
        item { Text("Choose payment method", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold) }
        item { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.PhoneAndroid, null, tint = HubGreen); Spacer(Modifier.width(12.dp)); Column { Text("M-Pesa", fontWeight = FontWeight.Bold); Text("Pay securely via M-Pesa", color = HubMuted, fontSize = 12.sp) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.RadioButtonChecked, null, tint = HubGreen) } } }
        item { OutlinedTextField(phone, { phone = it }, label = { Text("M-Pesa phone number") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
        item { if(message.isNotBlank()) Text(message,color=MaterialTheme.colorScheme.error) }
        item { if(waiting) { Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F2))){ Column(Modifier.padding(18.dp)){ CircularProgressIndicator(modifier=Modifier.size(28.dp)); Spacer(Modifier.height(10.dp)); Text("Waiting for M-Pesa confirmation…",fontWeight=FontWeight.Bold); Text("Complete the PIN prompt on your phone. We will continue only after Safaricom confirms payment.",color=HubMuted,fontSize=12.sp) } } } else Button(enabled=phone.isNotBlank()&&!reference.isNullOrBlank(),onClick={ vm.payMpesa(reference!!,phone){waiting=true} },modifier=Modifier.fillMaxWidth().height(52.dp),colors=ButtonDefaults.buttonColors(containerColor=HubGreen),shape=RoundedCornerShape(14.dp)){Text("Pay KSh ${order.total} with M-Pesa",fontWeight=FontWeight.Bold)} }
    } }
}

@Composable private fun SummaryRow(a: String, b: String, bold: Boolean = false) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(a, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal); Text(b, fontWeight = if (bold) FontWeight.ExtraBold else FontWeight.Bold, color = if (bold) HubBlue else HubInk) } }

@Composable
fun TrackingScreen(orderId: Int, vm: AppViewModel, onBack: () -> Unit) {
    var order by remember { mutableStateOf<OrderDto?>(null) }
    LaunchedEffect(orderId) { while (true) { runCatching { ApiClient.api.tracking(orderId) }.onSuccess { order = it }; delay(5000) } }
    Column(Modifier.fillMaxSize().background(HubBackground)) { AppTopBar("Track Your Order", onBack); LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { val center=order?.deliveryLat?.let{lat->order?.deliveryLng?.let{lng->LatLng(lat,lng)}} ?: LatLng(-1.286389,36.817223); val camera=rememberCameraPositionState{position=CameraPosition.fromLatLngZoom(center,14f)}; Card(Modifier.padding(horizontal=18.dp).fillMaxWidth().height(280.dp),shape=RoundedCornerShape(20.dp)){ Box{ GoogleMap(modifier=Modifier.fillMaxSize(),cameraPositionState=camera){ order?.riderLat?.let{rlat->order?.riderLng?.let{rlng->Marker(position=LatLng(rlat,rlng),title="Rider")} }; order?.deliveryLat?.let{dlat->order?.deliveryLng?.let{dlng->Marker(position=LatLng(dlat,dlng),title="Delivery")}} }; Text("LIVE",Modifier.align(Alignment.TopEnd).padding(14.dp).background(HubGreen,RoundedCornerShape(20.dp)).padding(horizontal=10.dp,vertical=5.dp),color=Color.White,fontSize=11.sp,fontWeight=FontWeight.Bold) } } }
        item { Card(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) { Text("Order #$orderId", fontWeight = FontWeight.Bold); Text(order?.let { "${it.companyName} • ${it.status}" } ?: "Loading…", color = HubMuted); order?.riderName?.let { Text("Rider: $it", fontWeight = FontWeight.Bold) }; order?.riderLat?.let { lat -> order?.riderLng?.let { lng -> Text("Live GPS: %.5f, %.5f".format(lat, lng), color = HubGreen, fontSize = 12.sp) } }; Spacer(Modifier.height(12.dp)); listOf("Order Confirmed", "Preparing Your Food", "Out for Delivery", "Arriving Soon").forEachIndexed { i, t -> Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) { Box(Modifier.size(18.dp).clip(CircleShape).background(if (i < 2) HubGreen else HubBorder)); Spacer(Modifier.width(12.dp)); Text(t, fontWeight = if (i < 2) FontWeight.Bold else FontWeight.Normal) } } } } }
        item { if (order?.status == "DELIVERED") Button(onClick = { vm.receive(orderId) }, Modifier.padding(horizontal = 18.dp).fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Mark Delivery Received") }; if (order?.status == "RECEIVED") Text("Delivery received. Live tracking has ended.", Modifier.padding(horizontal = 18.dp), color = HubGreen, fontWeight = FontWeight.Bold) }
    } }
}

@Composable
fun JobsScreen(vm: AppViewModel, onBack: () -> Unit, onJob: (JobDto) -> Unit) {
    Column(Modifier.fillMaxSize().background(HubBackground)) { AppTopBar("Jobs Marketplace", onBack, { IconButton(onClick = {}) { Icon(Icons.Default.Search, "Search") } }); LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { item { Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(true, {}, label = { Text("All Jobs") }); FilterChip(false, {}, label = { Text("On-site") }); FilterChip(false, {}, label = { Text("Remote") }) } }; items(vm.jobs.value) { j -> JobCard(j) { onJob(j) } } } }
}

@Composable
fun JobDetailsScreen(job: JobDto, vm: AppViewModel, onBack: () -> Unit) {
    var amount by remember { mutableStateOf(job.amount) }; var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(HubBackground)) { AppTopBar("Job Details", onBack); LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { item { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(20.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(HubPurple.copy(.12f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Work, null, tint = HubPurple) }; Spacer(Modifier.width(12.dp)); Column { Text(job.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold); Text(if (job.online) "Remote" else job.location, color = HubMuted) } }; Spacer(Modifier.height(18.dp)); Text("Budget", fontWeight = FontWeight.Bold); Text("KSh ${job.amount}", color = HubBlue, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(18.dp)); Text("Job Description", fontWeight = FontWeight.Bold); Text(job.description, color = HubMuted) } } }; item { OutlinedTextField(amount, { amount = it }, label = { Text("Your bid amount") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(message, { message = it }, label = { Text("Message to client") }, modifier = Modifier.fillMaxWidth(), minLines = 4); Button(onClick = { vm.bid(job.id, amount, message) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) { Text("Apply Now", fontWeight = FontWeight.Bold) }; OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.BookmarkBorder, null); Spacer(Modifier.width(8.dp)); Text("Save Job") } } } }
}

@Composable
fun ProfileScreen(vm: AppViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(HubBackground)) { AppTopBar("My Profile", onBack, { IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null) } }); LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { item { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) { Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(70.dp).clip(CircleShape).background(HubBlue.copy(.12f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = HubBlue, modifier = Modifier.size(38.dp)) }; Spacer(Modifier.width(14.dp)); Column { Text(vm.user.value?.name ?: "My Account", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold); Text(vm.user.value?.role ?: "Customer", color = HubMuted); Text("Verified account", color = HubGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp) } } } }; listOf("Personal Information" to Icons.Default.Person, "Delivery Addresses" to Icons.Default.LocationOn, "Payment Methods" to Icons.Default.CreditCard, "Order History" to Icons.Default.ReceiptLong, "My Jobs" to Icons.Default.Work, "Ratings & Reviews" to Icons.Default.Star, "Settings" to Icons.Default.Settings).forEach { (label, icon) -> item { Card(Modifier.fillMaxWidth().clickable {}, shape = RoundedCornerShape(14.dp)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = HubBlue); Spacer(Modifier.width(14.dp)); Text(label, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = HubMuted) } } } } } }
}

@Composable
fun RiderDashboardScreen(vm: AppViewModel, onBack: () -> Unit) {
    val context=LocalContext.current; val location=remember{LocationProvider(context)}; var permission by remember{mutableStateOf(ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)}; val launcher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){permission=it}; var deliveries by remember{mutableStateOf<List<OrderDto>>(emptyList())}
    LaunchedEffect(Unit){ runCatching{deliveries=ApiClient.api.riderOrders()} }
    LaunchedEffect(permission){
        if(permission){
            while(true){
                runCatching { deliveries = ApiClient.api.riderOrders() }
                val active = deliveries.any { it.riderName != null && it.status in setOf("PICKED_UP", "DELIVERED") }
                if(active){ location.current()?.let{ vm.updateRiderLocation(LocationRequest(it.latitude,it.longitude)) } }
                delay(10000)
            }
        }
    }
    Column(Modifier.fillMaxSize().background(HubBackground)){ AppTopBar("Rider Dashboard",onBack); LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){ item{Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=HubBlue)){Column(Modifier.padding(20.dp)){Row{Column(Modifier.weight(1f)){Text("Good morning",color=Color.White.copy(.8f));Text(vm.user.value?.name?:"Rider",color=Color.White,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.ExtraBold)};Text("APPROVED",color=Color.White,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(12.dp));Button(onClick={if(permission){runCatching{deliveries=ApiClient.api.riderOrders()}}else launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION)},colors=ButtonDefaults.buttonColors(containerColor=Color.White,contentColor=HubBlue),modifier=Modifier.fillMaxWidth()){Text(if(permission)"Refresh Available Deliveries" else "Enable GPS to Work")}}}}; item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){StatCard("Available",deliveries.count{it.status=="READY"}.toString(),Modifier.weight(1f));StatCard("Active",deliveries.count{it.riderName!=null&&it.status!="RECEIVED"}.toString(),Modifier.weight(1f));StatCard("GPS","ON",Modifier.weight(1f))}}; items(deliveries){o->Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)){Text(o.companyName,fontWeight=FontWeight.ExtraBold);Text("${o.deliveryAddress} • KSh ${o.total}",color=HubMuted,fontSize=12.sp);Spacer(Modifier.height(10.dp));if(o.status=="READY"&&o.riderName==null)Button(onClick={if(permission) location.current()?.let{vm.acceptDelivery(o.id,LocationRequest(it.latitude,it.longitude)){runCatching{deliveries=ApiClient.api.riderOrders()}}} else launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION)},modifier=Modifier.fillMaxWidth()){Text("Accept Delivery")}}}} } }
}

@Composable
fun CompanyDashboardScreen(vm: AppViewModel, onBack: () -> Unit) {
    val orders=vm.companyOrders.collectAsState().value
    Column(Modifier.fillMaxSize().background(HubBackground)){ AppTopBar("Company Dashboard",onBack); LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){ item{Text(vm.user.value?.name?:"Business",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.ExtraBold)}; item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){StatCard("Orders",orders.size.toString(),Modifier.weight(1f));StatCard("Preparing",orders.count{it.status=="PREPARING"}.toString(),Modifier.weight(1f));StatCard("Ready",orders.count{it.status=="READY"}.toString(),Modifier.weight(1f))}}; item{Text("Orders",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.ExtraBold)}; items(orders){o->Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)){Text("Order #${o.id}",fontWeight=FontWeight.ExtraBold);Text("${o.deliveryAddress} • ${o.status}",color=HubMuted);Text("KSh ${o.total}",color=HubBlue,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));when(o.status){"PAID"->Button(onClick={vm.updateCompanyOrder(o.id,"PREPARING")},modifier=Modifier.fillMaxWidth()){Text("Start Preparing")};"PREPARING"->Button(onClick={vm.updateCompanyOrder(o.id,"READY")},modifier=Modifier.fillMaxWidth()){Text("Mark Ready for Rider")}}}}}; item{Text("Rider pickup starts only after the company marks the order READY.",color=HubMuted,fontSize=12.sp)} } }
}

@Composable private fun StatCard(label: String, value: String, modifier: Modifier) { Card(modifier, shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp)) { Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold); Text(label, color = HubMuted, fontSize = 11.sp) } } }

@Composable
fun RatingScreen(orderId: Int, vm: AppViewModel, onBack: () -> Unit) {
    var score by remember { mutableStateOf(5) }; var comment by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(HubBackground)) { AppTopBar("Ratings & Reviews", onBack); Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("How was your delivery?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold); Text("Rate your rider and food company", color = HubMuted); Spacer(Modifier.height(24.dp)); Row { (1..5).forEach { n -> IconButton(onClick = { score = n }) { Icon(Icons.Default.Star, null, tint = if (n <= score) HubYellow else HubBorder, modifier = Modifier.size(40.dp)) } } }; Text("$score / 5", color = HubBlue, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(20.dp)); OutlinedTextField(comment, { comment = it }, label = { Text("Tell us about your experience") }, modifier = Modifier.fillMaxWidth(), minLines = 4); Spacer(Modifier.height(14.dp)); Button(onClick = { vm.rate(orderId, "ORDER_RIDER", score, comment) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) { Text("Submit Rating", fontWeight = FontWeight.Bold) } } }
}
