package com.workdeliveryhub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.workdeliveryhub.app.data.ApiClient
import com.workdeliveryhub.app.ui.AppViewModel
import com.workdeliveryhub.app.ui.HubTheme
import com.workdeliveryhub.app.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ApiClient.init(applicationContext)
        setContent {
            HubTheme {
                val vm: AppViewModel = viewModel()
                val nav = rememberNavController()
                NavHost(navController = nav, startDestination = "splash") {
                    composable("splash") { SplashScreen { nav.navigate(if (ApiClient.token == null) "home" else "dashboard") { popUpTo("splash") { inclusive = true } } } }
                    composable("home") { HomeScreen(vm, { nav.navigate("login") }, { nav.navigate("register") }, { nav.navigate("jobs") }, { c -> nav.navigate("order/${c.id}") }, { nav.navigate("profile") }) }
                    composable("login") { LoginScreen(vm, { nav.navigate("dashboard") { popUpTo("home") { inclusive = true } } }, { nav.navigate("register") }, { nav.popBackStack() }) }
                    composable("register") { RegisterScreen(vm, { nav.navigate("dashboard") { popUpTo("home") { inclusive = true } } }, { nav.popBackStack() }) }
                    composable("dashboard") { when(vm.user.value?.role) { "RIDER" -> RiderDashboardScreen(vm){ nav.navigate("home"){ popUpTo("dashboard"){inclusive=true} } }; "COMPANY" -> CompanyDashboardScreen(vm){ nav.navigate("home"){ popUpTo("dashboard"){inclusive=true} } }; else -> DashboardScreen(vm, { c -> nav.navigate("order/${c.id}") }, { id -> nav.navigate("tracking/$id") }, { nav.navigate("jobs") }, { nav.navigate("profile") }) } }
                    composable("jobs") { JobsScreen(vm, { nav.popBackStack() }, { j -> nav.navigate("job/${j.id}") }) }
                    composable("job/{id}", arguments = listOf(navArgument("id") { type = NavType.IntType })) { b -> vm.jobs.value.firstOrNull { it.id == b.arguments?.getInt("id") }?.let { JobDetailsScreen(it, vm) { nav.popBackStack() } } }
                    composable("profile") { ProfileScreen(vm) { nav.popBackStack() } }
                    composable("rider") { RiderDashboardScreen(vm) { nav.popBackStack() } }
                    composable("company") { CompanyDashboardScreen(vm) { nav.popBackStack() } }
                    composable("order/{companyId}", arguments = listOf(navArgument("companyId") { type = NavType.IntType })) { b -> vm.companies.value.firstOrNull { it.id == b.arguments?.getInt("companyId") }?.let { c -> OrderScreen(c, vm, { o -> nav.navigate("payment/${o.id}") }, { nav.popBackStack() }) } }
                    composable("payment/{orderId}", arguments = listOf(navArgument("orderId") { type = NavType.IntType })) { b -> val id = b.arguments?.getInt("orderId") ?: 0; vm.orders.value.firstOrNull { it.id == id }?.let { o -> PaymentScreen(o, vm, { nav.navigate("tracking/$id") { popUpTo("payment/$id") { inclusive = true } } }, { nav.popBackStack() }) } }
                    composable("tracking/{orderId}", arguments = listOf(navArgument("orderId") { type = NavType.IntType })) { b -> TrackingScreen(b.arguments?.getInt("orderId") ?: 0, vm) { nav.popBackStack() } }
                    composable("rating/{orderId}", arguments = listOf(navArgument("orderId") { type = NavType.IntType })) { b -> RatingScreen(b.arguments?.getInt("orderId") ?: 0, vm) { nav.popBackStack() } }
                }
            }
        }
    }
}
