package com.workdeliveryhub.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val HubBlue = Color(0xFF1261E8)
val HubBlueDark = Color(0xFF0B3D91)
val HubYellow = Color(0xFFFFC107)
val HubGreen = Color(0xFF16A36A)
val HubPurple = Color(0xFF7B4DFF)
val HubOrange = Color(0xFFFF8A00)
val HubInk = Color(0xFF102A43)
val HubMuted = Color(0xFF6B7C93)
val HubBackground = Color(0xFFF6F8FC)
val HubBorder = Color(0xFFE3EAF4)

private val Scheme = lightColorScheme(
    primary = HubBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE7F0FF),
    onPrimaryContainer = HubBlueDark,
    secondary = HubGreen,
    onSecondary = Color.White,
    tertiary = HubOrange,
    background = HubBackground,
    onBackground = HubInk,
    surface = Color.White,
    onSurface = HubInk,
    surfaceVariant = Color(0xFFF0F4FA),
    onSurfaceVariant = HubMuted,
    error = Color(0xFFD92D20),
    errorContainer = Color(0xFFFEE4E2)
)

@Composable
fun HubTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Typography(), content = content)
}
