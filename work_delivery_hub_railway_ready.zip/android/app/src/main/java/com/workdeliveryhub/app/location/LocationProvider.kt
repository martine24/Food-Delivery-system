package com.workdeliveryhub.app.location

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

data class DeviceLocation(val latitude: Double, val longitude: Double)
class LocationProvider(context: Context) {
    private val client = LocationServices.getFusedLocationProviderClient(context)
    @SuppressLint("MissingPermission")
    suspend fun current(): DeviceLocation? = suspendCancellableCoroutine { cont ->
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).addOnSuccessListener { l -> cont.resume(l?.let { DeviceLocation(it.latitude, it.longitude) }) }.addOnFailureListener { cont.resume(null) }
    }
}
