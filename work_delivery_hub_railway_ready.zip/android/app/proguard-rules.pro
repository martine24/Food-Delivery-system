# Retrofit/Gson DTOs and API contract must survive R8.
-keepattributes Signature
-keepattributes RuntimeVisibleAnnotations,RuntimeInvisibleAnnotations,RuntimeVisibleParameterAnnotations,RuntimeInvisibleParameterAnnotations
-keep class com.workdeliveryhub.app.data.** { *; }
-keep interface com.workdeliveryhub.app.data.HubApi { *; }
-dontwarn javax.annotation.**
