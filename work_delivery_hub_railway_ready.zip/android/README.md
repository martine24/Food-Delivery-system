# Work & Delivery Hub — Native Android

Native Android client built with **Kotlin + Jetpack Compose** and connected to the hardened Django backend in this delivery package. It is not a WebView.

## Connected production contract
The app uses authenticated JSON endpoints under `/api/v1/` for login, profile, companies/menu, orders, M-Pesa initiation, jobs/bids, rider acceptance/location, live tracking, delivery receipt and ratings. Customer ordering requires device GPS; rider acceptance and location updates also require GPS.

## Configure before release
Do not hard-code production secrets. Build with:

`gradle bundleRelease -PAPI_BASE_URL=https://your-real-domain/ -PMAPS_API_KEY=YOUR_RESTRICTED_GOOGLE_MAPS_KEY`

The backend `.env` must contain the real PostgreSQL, HTTPS, Django secret, Safaricom Daraja live credentials and callback URLs. PayPal remains disabled unless a supported presentment currency and verified conversion flow are configured.

## Android release signing
Configure a private upload/release keystore in Android Studio or CI. Never commit the keystore or passwords. The source package deliberately does not contain signing secrets.

## Build verification
CI uses Gradle 8.10.2 and Android SDK 35. The current execution environment does not contain the Android SDK/Gradle distribution and has no outbound package-network access, so a local APK/AAB cannot be honestly certified from this environment. The GitHub Actions workflow is the reproducible build path.
