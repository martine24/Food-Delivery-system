#!/bin/sh
set -eu

echo "[Railway] Running database migrations..."
python manage.py migrate --noinput

echo "[Railway] Collecting static files..."
python manage.py collectstatic --noinput

: "${PORT:=8000}"
echo "[Railway] Starting Gunicorn on port ${PORT}..."
exec gunicorn config.wsgi:application \
  --bind "0.0.0.0:${PORT}" \
  --workers "${WEB_CONCURRENCY:-3}" \
  --timeout "${GUNICORN_TIMEOUT:-120}" \
  --access-logfile -
