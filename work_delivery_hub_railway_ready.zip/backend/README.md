# Work & Delivery Hub — V2.3 Commercial

Django marketplace for food delivery and general jobs, with manager-approved riders, live GPS tracking, customer delivery confirmation, ratings, M-Pesa and PayPal checkout, platform commission, and transactional notifications.

## Commercial workflow

### Food delivery
1. Customer registers with phone, town/location, ID and profile photo.
2. Customer places an order and MUST grant browser GPS permission for the delivery destination; the server rejects orders without valid latitude/longitude.
3. Customer pays through M-Pesa or PayPal.
4. Approved company prepares the order and marks it READY.
5. Approved rider must grant GPS permission and be within the configured acceptance radius.
6. Rider accepts the order. The customer immediately receives an in-app notification, email when configured, and SMS when Africa's Talking is configured.
7. Rider shares live GPS while the delivery is active.
8. Rider marks the delivery DELIVERED.
9. Customer confirms RECEIVED.
10. Live tracking ends and rider coordinates are cleared. Only then is payout eligible.
11. Customer can rate both rider and company.

### Jobs
1. User posts a job.
2. Workers bid.
3. Poster awards a bid.
4. Poster pays through M-Pesa or PayPal.
5. Worker completes/submits the work.
6. Poster accepts the work.
7. 5% platform fee is retained and 95% becomes the provider amount.
8. Verified ratings can be left for worker and poster after completion.

## Real payment configuration

The code does not fake payment success. A transaction becomes PAID only after M-Pesa callback confirmation or PayPal capture confirmation. Production credentials must be supplied in environment variables.

### M-Pesa
Set production credentials:
- `MPESA_ENVIRONMENT=production`
- `MPESA_CONSUMER_KEY`
- `MPESA_CONSUMER_SECRET`
- `MPESA_SHORTCODE`
- `MPESA_PASSKEY`
- `MPESA_CALLBACK_URL=https://YOUR-DOMAIN/payments/mpesa/callback/`

For payouts, configure the approved Safaricom B2C credentials and callback URLs.

### PayPal
Create a live PayPal REST app and configure:
- `PAYPAL_ENVIRONMENT=production`
- `PAYPAL_CLIENT_ID`
- `PAYPAL_CLIENT_SECRET`
- `PAYPAL_CURRENCY=USD` (or another PayPal-supported checkout currency)
- `PAYPAL_RETURN_URL=https://YOUR-DOMAIN/payments/paypal/return/`
- `PAYPAL_CANCEL_URL=https://YOUR-DOMAIN/payments/paypal/cancel/`
- `PAYPAL_WEBHOOK_ID`

Register this HTTPS webhook with PayPal:
`https://YOUR-DOMAIN/payments/paypal/webhook/`

Recommended events include payment capture completion and checkout completion. The webhook handler verifies the PayPal signature before changing a transaction.

## Customer notifications

V2.3 sends a notification when a rider picks up an order:
- in-app notification is always stored;
- email is sent when SMTP is configured;
- SMS is sent when Africa's Talking is configured.

Africa's Talking live SMS requires an account, API key and approved sender ID. Configure:
- `AT_ENABLED=True`
- `AT_USERNAME`
- `AT_API_KEY`
- `AT_SENDER_ID`
- `AT_SMS_URL=https://api.africastalking.com/version1/messaging`

## HostPinnacle deployment

HostPinnacle currently advertises Django hosting as well as VPS hosting. For this application, use a Django-capable plan that permits the Python runtime, PostgreSQL, HTTPS, long-running Gunicorn process and required outbound HTTPS connections. A VPS is the safest choice if your hosting package does not provide process management for Django/Gunicorn.

### First deployment

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py collectstatic --noinput
python manage.py check --deploy
```

Start production application server:

```bash
gunicorn config.wsgi:application --bind 127.0.0.1:8000 --workers 3 --timeout 60
```

Put Nginx/Apache in front of Gunicorn, enable HTTPS, point the domain to the server, and configure the public callback URLs before enabling production payments.

## Required production safeguards

Before taking real customer money, complete:

- HTTPS and valid certificate
- PostgreSQL production database
- automated database backups and restore test
- real M-Pesa sandbox end-to-end test, then production credentials
- real PayPal sandbox end-to-end test, then live credentials
- PayPal webhook registration and signature verification test
- M-Pesa callback test from a public HTTPS URL
- M-Pesa B2C payout test if platform payouts are enabled
- SMTP test
- transactional SMS test and sender-ID approval
- GPS tests on Android and iPhone
- file upload/identity access review
- admin account MFA/password policy outside the application if available
- privacy policy, terms, refund/dispute policy, and data-retention policy
- business/payment/legal compliance appropriate to the countries where the platform operates
- monitoring and error alerting

## Important payment rule

Never mark a transaction PAID because a browser return page says it succeeded. M-Pesa callback and PayPal server-side capture/webhook verification are the sources of truth.

## V2.3 database

Run the new migration after upgrading from V2.2:

```bash
python manage.py migrate
```

The V2.3 migration adds PayPal order tracking and persistent notifications.


## Production security notes
- Customer delivery GPS is mandatory and validated server-side.
- Identity documents and job submissions must not be served as public media; use the supplied Nginx deny rules (or equivalent private storage policy).
- Set `DJANGO_DEBUG=False`, a strong unique `DJANGO_SECRET_KEY`, exact `DJANGO_ALLOWED_HOSTS`, and HTTPS before launch.
- Do not use the sample Docker/PostgreSQL password in production.
- Run the application behind a production WSGI server and HTTPS reverse proxy.


### Preflight before opening the site to customers
Run `./scripts/production_preflight.sh` on the production server after installing dependencies and loading the real `.env`. This checks Django deployment settings, migration consistency, static collection and the automated test suite. It does not replace live M-Pesa/PayPal callback tests.


## PayPal currency warning
As of October 2026, PayPal's published REST checkout currency list does not list KES. The build therefore keeps PayPal disabled by default. Do not send KES amounts directly to PayPal. The production configuration intentionally refuses `PAYPAL_CURRENCY=KES` so the platform cannot silently mischarge or fail at checkout. If PayPal is required for Kenyan-shilling orders, implement and test a supported-currency FX/presentment flow and clearly show the converted amount before payment.

## Native Android API
The native Kotlin/Compose client uses `/api/v1/` JSON endpoints. Authentication uses short-lived-in-practice bearer-style random tokens stored only as SHA-256 hashes in `marketplace.ApiToken`; revoke tokens by setting `revoked_at` through an administrative workflow. The API enforces customer GPS on order creation and rider GPS on delivery acceptance/location updates.

Before public launch, set the native app `BASE_URL` to the production HTTPS domain and configure real M-Pesa credentials/callbacks. Do not commit provider secrets or a Google Maps API key to source control.
