from django.urls import path
from . import views
urlpatterns=[path("<str:transaction_ref>/",views.payment_checkout,name="payments_checkout"),path("mpesa/callback/",views.mpesa_callback,name="mpesa_callback")]
