from django.urls import path
from . import views
urlpatterns=[path("profile/",views.rider_profile,name="rider_profile")]
