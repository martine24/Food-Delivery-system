import requests
from django.conf import settings
from django.core.mail import send_mail
from .models import Notification


def _normalise_phone(phone):
    phone = (phone or '').strip().replace(' ', '').replace('-', '')
    if phone.startswith('+'): phone = phone[1:]
    if phone.startswith('0'): phone = '254' + phone[1:]
    return phone


def send_sms(phone, message):
    if not getattr(settings, 'AT_API_KEY', '') or not getattr(settings, 'AT_USERNAME', '') or not getattr(settings, 'AT_SENDER_ID', ''):
        return False
    payload = {'username': settings.AT_USERNAME, 'to': _normalise_phone(phone), 'message': message, 'from': settings.AT_SENDER_ID}
    r = requests.post(settings.AT_SMS_URL, headers={'apiKey': settings.AT_API_KEY, 'Accept': 'application/json'}, data=payload, timeout=15)
    r.raise_for_status()
    return True


def notify(user, title, message, *, metadata=None):
    Notification.objects.create(user=user, title=title, message=message, channel='IN_APP', metadata=metadata or {})
    if getattr(settings, 'EMAIL_HOST', '') and user.email:
        try:
            send_mail(title, message, settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=True)
        except Exception:
            pass
    if getattr(settings, 'AT_ENABLED', False) and user.phone:
        try:
            send_sms(user.phone, message[:480])
        except Exception:
            pass
