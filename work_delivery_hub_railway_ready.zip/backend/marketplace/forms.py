from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
from pathlib import Path
from PIL import Image
from .models import User, CompanyProfile, RiderProfile, MenuItem, Job, Bid, JobSubmission, Order, Rating

MAX_UPLOAD = 5 * 1024 * 1024
ALLOWED_IMAGE = {"image/jpeg", "image/png", "image/webp"}
ALLOWED_DOCUMENT_EXTENSIONS = {"pdf", "jpg", "jpeg", "png", "webp", "doc", "docx", "txt", "xlsx", "csv"}

def validate_upload(upload, *, image=False):
    if not upload: return
    if upload.size > MAX_UPLOAD: raise ValidationError("File must be 5 MB or smaller.")
    ext = Path(upload.name or "").suffix.lower().lstrip(".")
    if ext not in ALLOWED_DOCUMENT_EXTENSIONS:
        raise ValidationError("Unsupported file type. Use PDF, JPG, PNG, WebP, DOC, DOCX, TXT, XLSX or CSV.")
    if image:
        if getattr(upload, "content_type", "") not in ALLOWED_IMAGE:
            raise ValidationError("Use JPG, PNG or WebP images.")
        try:
            upload.seek(0); img = Image.open(upload); img.verify(); upload.seek(0)
        except Exception:
            upload.seek(0)
            raise ValidationError("The uploaded image is invalid or corrupted.")

class RegisterForm(UserCreationForm):
    class Meta:
        model = User
        fields = ["username","first_name","last_name","email","phone","town","town_location","id_number","id_document","profile_photo","role","password1","password2"]
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields["town"].label = "Town"; self.fields["town_location"].label = "Town / Location"; self.fields["town"].required = True; self.fields["town_location"].required = True; self.fields["id_document"].required = True; self.fields["profile_photo"].required = True
    def clean_role(self):
        role=self.cleaned_data["role"]
        if role == "MANAGER": raise ValidationError("Manager accounts are created by an administrator.")
        return role
    def clean_id_document(self):
        f=self.cleaned_data["id_document"]; validate_upload(f); return f
    def clean_profile_photo(self):
        f=self.cleaned_data["profile_photo"]; validate_upload(f,image=True); return f

class CompanyForm(forms.ModelForm):
    class Meta: model=CompanyProfile; fields=["business_name","description","address","logo"]
    def clean_logo(self): f=self.cleaned_data["logo"]; validate_upload(f,image=True); return f
class RiderForm(forms.ModelForm):
    class Meta: model=RiderProfile; fields=["vehicle_type","license_number"]
class MenuItemForm(forms.ModelForm):
    class Meta: model=MenuItem; fields=["name","description","price","image","available"]
    def clean_image(self): f=self.cleaned_data["image"]; validate_upload(f,image=True); return f
class JobForm(forms.ModelForm):
    class Meta:
        model=Job; fields=["title","description","location","is_online","amount"]
        widgets={"description":forms.Textarea(attrs={"rows":6})}
class BidForm(forms.ModelForm):
    class Meta:
        model=Bid; fields=["proposed_amount","message"]; widgets={"message":forms.Textarea(attrs={"rows":4})}
class SubmissionForm(forms.ModelForm):
    class Meta:
        model=JobSubmission; fields=["text","file"]; widgets={"text":forms.Textarea(attrs={"rows":7})}
    def clean_file(self): f=self.cleaned_data["file"]; validate_upload(f); return f
class OrderForm(forms.ModelForm):
    class Meta:
        model=Order
        fields=["delivery_address","delivery_phone","delivery_lat","delivery_lng","notes"]
        labels={"delivery_address":"Delivery address","delivery_phone":"Delivery contact","notes":"Additional instructions / comments"}
        widgets={"delivery_address":forms.TextInput(attrs={"placeholder":"Building, street, landmark"}),"delivery_phone":forms.TextInput(attrs={"placeholder":"+254 7XX XXX XXX"}),"notes":forms.Textarea(attrs={"rows":4,"maxlength":1000,"placeholder":"Optional: dietary requests, gate instructions, call-on-arrival notes, etc."}), "delivery_lat":forms.HiddenInput(), "delivery_lng":forms.HiddenInput()}

    def clean(self):
        cleaned = super().clean()
        lat = cleaned.get("delivery_lat")
        lng = cleaned.get("delivery_lng")
        if lat is None or lng is None:
            raise ValidationError("Your delivery GPS location is required. Please allow location access and set your current delivery point before ordering.")
        try:
            from decimal import Decimal
            lat = Decimal(str(lat)); lng = Decimal(str(lng))
            if not (Decimal("-90") <= lat <= Decimal("90") and Decimal("-180") <= lng <= Decimal("180")):
                raise ValueError
        except (TypeError, ValueError, ArithmeticError):
            raise ValidationError("A valid delivery GPS location is required.")
        cleaned["delivery_lat"] = lat.quantize(Decimal("0.0000001"))
        cleaned["delivery_lng"] = lng.quantize(Decimal("0.0000001"))
        return cleaned



class RatingForm(forms.ModelForm):
    class Meta:
        model = Rating
        fields = ["score", "comment"]
        widgets = {"score": forms.Select(choices=[(i, f"{i} / 5") for i in range(5, 0, -1)]), "comment": forms.Textarea(attrs={"rows": 4, "maxlength": 1000})}
