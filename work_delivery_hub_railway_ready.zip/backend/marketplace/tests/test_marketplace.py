from decimal import Decimal
from django.test import TestCase, Client, override_settings
from django.urls import reverse
from django.utils import timezone
from marketplace.models import User, Job, Bid, Transaction, RiderProfile, CompanyProfile, Order, Delivery, Rating

class MarketplaceTests(TestCase):
    def make_user(self, username, role="CUSTOMER", verified=True):
        return User.objects.create_user(username=username,password="StrongPass123!",phone=f"25470000{len(User.objects.all())+1:03d}",id_number=f"ID{len(User.objects.all())+1}",role=role,id_document="identity/id.pdf",profile_photo="profiles/p.jpg",is_identity_verified=verified)

    def test_platform_fee_is_exactly_five_percent(self):
        payer=self.make_user("payer")
        tx=Transaction.create_for(payer=payer,gross_amount=Decimal("1000.00"),transaction_type="JOB")
        self.assertEqual(tx.platform_fee,Decimal("50.00")); self.assertEqual(tx.net_amount,Decimal("950.00"))

    def test_unapproved_rider_cannot_take_delivery(self):
        rider=self.make_user("rider", "RIDER")
        RiderProfile.objects.create(user=rider,vehicle_type="Bike")
        self.client.force_login(rider)
        response=self.client.post(reverse("take_delivery",args=[9999]))
        self.assertEqual(response.status_code,403)

    def test_worker_cannot_submit_before_payment(self):
        poster=self.make_user("poster")
        worker=self.make_user("worker")
        job=Job.objects.create(poster=poster,title="Test",description="Work",location="Online",is_online=True,amount=100)
        job.assigned_to=worker; job.status="AWARDED"; job.save()
        self.client.force_login(worker)
        response=self.client.get(reverse("submit_job",args=[job.id]))
        self.assertRedirects(response,reverse("job_detail",args=[job.id]))

    def test_rider_approval_grants_identity_verification(self):
        manager=self.make_user("manager","MANAGER")
        rider=self.make_user("rider2","RIDER",verified=False)
        profile=RiderProfile.objects.create(user=rider,vehicle_type="Bike")
        self.client.force_login(manager)
        self.client.post(reverse("approve_rider",args=[profile.id]))
        rider.refresh_from_db(); profile.refresh_from_db()
        self.assertTrue(rider.is_identity_verified); self.assertEqual(profile.status,"APPROVED")

    def test_customer_confirmation_ends_tracking_and_enables_rating(self):
        customer=self.make_user("cust3")
        rider=self.make_user("rider3","RIDER",verified=True)
        rider_profile=RiderProfile.objects.create(user=rider,vehicle_type="Bike",status="APPROVED")
        company_user=self.make_user("company3","COMPANY",verified=True)
        company=CompanyProfile.objects.create(user=company_user,business_name="Food Co",address="Town",status="APPROVED")
        order=Order.objects.create(customer=customer,company=company,delivery_address="Point",delivery_phone=customer.phone,delivery_lat=-1.28,delivery_lng=36.82,status="DELIVERED",subtotal=100,total=100)
        delivery=Delivery.objects.create(order=order,rider=rider,status="DELIVERED",current_lat=-1.29,current_lng=36.83,location_updated_at=timezone.now())
        tx=Transaction.create_for(payer=customer,gross_amount=100,transaction_type="ORDER",order=order,payee=company_user); tx.status="PAID"; tx.save(update_fields=["status"])
        self.client.force_login(customer)
        response=self.client.post(reverse("confirm_delivery_received",args=[order.id]))
        self.assertRedirects(response,reverse("order_tracking",args=[order.id]))
        order.refresh_from_db(); delivery.refresh_from_db()
        self.assertEqual(order.status,"RECEIVED"); self.assertIsNone(delivery.current_lat); self.assertIsNone(delivery.current_lng); self.assertIsNotNone(delivery.completed_at)
        self.client.post(reverse("rate_order",args=[order.id]),{"kind":"ORDER_RIDER","score":5,"comment":"Good"})
        self.client.post(reverse("rate_order",args=[order.id]),{"kind":"ORDER_COMPANY","score":4,"comment":"Good"})
        self.assertEqual(Rating.objects.filter(order=order).count(),2)

    def test_rating_cannot_be_submitted_before_receipt(self):
        customer=self.make_user("cust4"); company_user=self.make_user("company4","COMPANY",verified=True); company=CompanyProfile.objects.create(user=company_user,business_name="Food Co",address="Town",status="APPROVED")
        order=Order.objects.create(customer=customer,company=company,delivery_address="Point",status="DELIVERED",subtotal=50,total=50)
        self.client.force_login(customer)
        response=self.client.post(reverse("rate_order",args=[order.id]),{"kind":"ORDER_COMPANY","score":5})
        self.assertEqual(response.status_code,404)
