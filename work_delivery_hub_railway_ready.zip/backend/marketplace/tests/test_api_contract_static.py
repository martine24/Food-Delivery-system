from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
API = (ROOT / "marketplace" / "api.py").read_text()
URLS = (ROOT / "config" / "urls.py").read_text()
MODELS = (ROOT / "marketplace" / "models.py").read_text()


def test_native_api_routes_are_registered():
    for route in [
        'api/v1/auth/login/', 'api/v1/auth/register/', 'api/v1/auth/logout/',
        'api/v1/me/', 'api/v1/companies/', 'api/v1/orders/',
        'api/v1/jobs/', 'api/v1/rider/orders/', 'api/v1/rider/location/',
        'api/v1/orders/<int:pk>/tracking/', 'api/v1/orders/<int:pk>/receive/',
        'api/v1/orders/<int:pk>/rating/', 'api/v1/payments/mpesa/',
        'api/v1/payments/<str:reference>/', 'api/v1/company/orders/',
        'api/v1/notifications/'
    ]:
        assert route in URLS


def test_security_and_money_controls_exist():
    assert 'expires_at=timezone.now()+timezone.timedelta(days=30)' in API
    assert 'expires_at__gt=timezone.now()' in API
    assert 'return csrf_exempt(wrapped)' in API
    assert 'Delivery address and valid live GPS coordinates are required.' in API
    assert 'Current rider GPS is required before acceptance.' in API
    assert 'MpesaGateway().stk_push' in API
    assert 'Transaction.objects.select_related' in API
    assert 'platform_fee=fee,total=total' in API
    assert 'platform_fee=o.platform_fee' in API
    assert 'expose_destination = is_customer or is_assigned_rider or is_company' in API
    assert 'Live GPS updates are only accepted while you have an active delivery.' in API
    assert 'expires_at = models.DateTimeField' in MODELS
