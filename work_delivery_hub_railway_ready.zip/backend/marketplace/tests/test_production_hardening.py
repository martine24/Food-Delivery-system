import json
from decimal import Decimal
from unittest.mock import patch
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from marketplace.forms import OrderForm
from marketplace.models import User, CompanyProfile, MenuItem, Order, Transaction, RiderProfile, Delivery


class ProductionHardeningTests(TestCase):
    def make_user(self, username, role="CUSTOMER"):
        n = User.objects.count() + 1
        return User.objects.create_user(
            username=username,
            password="StrongPass123!",
            phone=f"254711000{n:03d}",
            id_number=f"ID-PROD-{n}",
            role=role,
            town="Nairobi",
            town_location="Nairobi",
            id_document="identity/id.pdf",
            profile_photo="profiles/p.jpg",
        )

    def make_company(self):
        owner = self.make_user("company", "COMPANY")
        company = CompanyProfile.objects.create(
            user=owner, business_name="Food Co", address="Nairobi", status="APPROVED"
        )
        item = MenuItem.objects.create(company=company, name="Meal", price=Decimal("250.00"), available=True)
        return company, item

    def test_order_form_rejects_missing_gps(self):
        form = OrderForm(data={
            "delivery_address": "Nairobi",
            "delivery_phone": "254711000001",
            "delivery_lat": "",
            "delivery_lng": "",
            "notes": "Please call on arrival",
        })
        self.assertFalse(form.is_valid())
        self.assertIn("GPS", str(form.errors))

    def test_order_creation_requires_gps_server_side(self):
        company, item = self.make_company()
        customer = self.make_user("customer")
        self.client.force_login(customer)
        response = self.client.post(reverse("create_order", args=[company.id]), {
            "item_%s" % item.id: "2",
            "delivery_address": "Nairobi",
            "delivery_phone": customer.phone,
            "delivery_lat": "",
            "delivery_lng": "",
            "notes": "Call on arrival",
        })
        self.assertRedirects(response, reverse("home"))
        self.assertEqual(Order.objects.count(), 0)

    def test_valid_order_stores_quantities_notes_and_gps(self):
        company, item = self.make_company()
        customer = self.make_user("customer2")
        self.client.force_login(customer)
        response = self.client.post(reverse("create_order", args=[company.id]), {
            "item_%s" % item.id: "3",
            "delivery_address": "Nairobi",
            "delivery_phone": customer.phone,
            "delivery_lat": "-1.286389",
            "delivery_lng": "36.817223",
            "notes": "Call when outside",
        })
        self.assertEqual(response.status_code, 302)
        order = Order.objects.get()
        self.assertEqual(order.delivery_lat, Decimal("-1.2863890"))
        self.assertEqual(order.delivery_lng, Decimal("36.8172230"))
        self.assertEqual(order.notes, "Call when outside")
        self.assertEqual(order.items.get().quantity, 3)
        self.assertEqual(order.subtotal, Decimal("750.00"))


    def test_order_transaction_uses_order_fee_snapshot(self):
        company, item = self.make_company()
        customer = self.make_user("customer_fee_snapshot")
        order = Order.objects.create(
            customer=customer, company=company, delivery_address="Nairobi",
            delivery_phone=customer.phone, delivery_lat=-1.28, delivery_lng=36.82,
            subtotal=1000, platform_fee=Decimal("75.00"), total=Decimal("1075.00")
        )
        tx = Transaction.create_for(
            payer=customer, gross_amount=order.total, platform_fee=order.platform_fee,
            transaction_type="ORDER", order=order, payee=company.user
        )
        self.assertEqual(tx.gross_amount, Decimal("1075.00"))
        self.assertEqual(tx.platform_fee, Decimal("75.00"))
        self.assertEqual(tx.net_amount, Decimal("1000.00"))

    def test_mpesa_callback_rejects_wrong_amount(self):
        company, _ = self.make_company()
        customer = self.make_user("customer3")
        order = Order.objects.create(
            customer=customer, company=company, delivery_address="Nairobi",
            delivery_phone=customer.phone, delivery_lat=-1.28, delivery_lng=36.82,
            subtotal=500, total=500,
        )
        tx = Transaction.create_for(payer=customer, gross_amount=500, transaction_type="ORDER", order=order, payee=company.user)
        tx.provider = "MPESA"
        tx.provider_reference = "ws_CO_123"
        tx.save(update_fields=["provider", "provider_reference"])
        payload = {"Body": {"stkCallback": {
            "ResultCode": 0,
            "CheckoutRequestID": "ws_CO_123",
            "CallbackMetadata": {"Item": [{"Name": "Amount", "Value": 100}]},
        }}}
        response = self.client.post(reverse("mpesa_callback"), data=json.dumps(payload), content_type="application/json")
        self.assertEqual(response.status_code, 200)
        tx.refresh_from_db()
        self.assertEqual(tx.status, "FAILED")

    def test_customer_receipt_clears_delivery_and_rider_coordinates(self):
        company, _ = self.make_company()
        customer = self.make_user("customer4")
        rider = self.make_user("rider4", "RIDER")
        profile = RiderProfile.objects.create(user=rider, vehicle_type="Bike", status="APPROVED", current_lat=-1.28, current_lng=36.82, location_updated_at=timezone.now())
        order = Order.objects.create(customer=customer, company=company, delivery_address="Nairobi", delivery_phone=customer.phone, delivery_lat=-1.28, delivery_lng=36.82, status="DELIVERED", subtotal=100, total=100)
        delivery = Delivery.objects.create(order=order, rider=rider, status="DELIVERED", current_lat=-1.29, current_lng=36.83, location_updated_at=timezone.now())
        tx = Transaction.create_for(payer=customer, gross_amount=100, transaction_type="ORDER", order=order, payee=company.user)
        tx.status = "PAID"; tx.save(update_fields=["status"])
        self.client.force_login(customer)
        self.client.post(reverse("confirm_delivery_received", args=[order.id]))
        delivery.refresh_from_db(); profile.refresh_from_db()
        self.assertIsNone(delivery.current_lat)
        self.assertIsNone(delivery.current_lng)
        self.assertIsNone(profile.current_lat)
        self.assertIsNone(profile.current_lng)
