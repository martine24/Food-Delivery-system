from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils import timezone
from .models import *

@admin.action(description="Approve selected riders")
def approve_riders(modeladmin,request,queryset): queryset.update(status="APPROVED",approved_at=timezone.now(),approved_by=request.user)
@admin.action(description="Approve selected companies")
def approve_companies(modeladmin,request,queryset): queryset.update(status="APPROVED",approved_at=timezone.now(),approved_by=request.user)
@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display=("username","phone","role","is_identity_verified","is_staff","created_at")
    list_filter=("role","is_identity_verified","is_staff")
    search_fields=("username","phone","id_number","email")
    fieldsets=UserAdmin.fieldsets+(("Marketplace identity",{"fields":("role","phone","id_number","id_document","profile_photo","is_identity_verified","created_at")}),)
    readonly_fields=("created_at",)
@admin.register(RiderProfile)
class RiderAdmin(admin.ModelAdmin):
    list_display=("user","vehicle_type","status","approved_at")
    list_filter=("status","vehicle_type")
    search_fields=("user__username","user__phone","user__id_number")
    actions=[approve_riders]
@admin.register(CompanyProfile)
class CompanyAdmin(admin.ModelAdmin):
    list_display=("business_name","user","status","approved_at","created_at")
    list_filter=("status",); search_fields=("business_name","user__username","user__phone"); actions=[approve_companies]
@admin.register(PlatformSetting)
class PlatformSettingAdmin(admin.ModelAdmin):
    list_display=("platform_fee_percent","updated_at","updated_by")
    readonly_fields=("updated_at","updated_by")

    def has_add_permission(self, request):
        return request.user.is_superuser and not PlatformSetting.objects.filter(pk=1).exists()

    def has_change_permission(self, request, obj=None):
        return request.user.is_superuser

    def has_delete_permission(self, request, obj=None):
        return False

    def save_model(self, request, obj, form, change):
        old = PlatformSetting.objects.filter(pk=1).first()
        old_value = old.platform_fee_percent if old else Decimal("5.00")
        obj.pk = 1
        obj.updated_by = request.user
        super().save_model(request, obj, form, change)
        if old_value != obj.platform_fee_percent:
            PlatformFeeChange.objects.create(old_percent=old_value, new_percent=obj.platform_fee_percent, changed_by=request.user)

@admin.register(PlatformFeeChange)
class PlatformFeeChangeAdmin(admin.ModelAdmin):
    list_display=("old_percent","new_percent","changed_by","changed_at")
    readonly_fields=("old_percent","new_percent","changed_by","changed_at")
    def has_add_permission(self, request): return False
    def has_change_permission(self, request, obj=None): return False
    def has_delete_permission(self, request, obj=None): return False

@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display=("reference","transaction_type","gross_amount","platform_fee","net_amount","status","payout_status","provider","created_at","released_at")
    list_filter=("transaction_type","status","provider"); search_fields=("reference","provider_reference","payout_reference","payer__username","payee__username"); readonly_fields=("reference","gross_amount","platform_fee","net_amount","metadata","payout_reference","created_at","paid_at","released_at")
@admin.register(Rating)
class RatingAdmin(admin.ModelAdmin):
    list_display=("kind","rater","rated","score","order","job","created_at")
    list_filter=("kind","score")
    search_fields=("rater__username","rated__username","comment")

admin.site.register(MenuItem); admin.site.register(Order); admin.site.register(OrderItem); admin.site.register(Delivery); admin.site.register(Job); admin.site.register(Bid); admin.site.register(JobSubmission)

from .models import Notification
admin.site.register(Notification)
