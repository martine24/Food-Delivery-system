import base64
from datetime import datetime
import requests
from django.conf import settings

class MpesaGateway:
    @property
    def base_url(self):
        return "https://api.safaricom.co.ke" if settings.MPESA_ENVIRONMENT == "production" else "https://sandbox.safaricom.co.ke"
    def enabled(self):
        return all([settings.MPESA_CONSUMER_KEY, settings.MPESA_CONSUMER_SECRET, settings.MPESA_SHORTCODE, settings.MPESA_PASSKEY, settings.MPESA_CALLBACK_URL])
    def token(self):
        raw=base64.b64encode(f"{settings.MPESA_CONSUMER_KEY}:{settings.MPESA_CONSUMER_SECRET}".encode()).decode()
        r=requests.get(self.base_url+"/oauth/v1/generate?grant_type=client_credentials",headers={"Authorization":"Basic "+raw},timeout=20); r.raise_for_status()
        return r.json()["access_token"]
    def stk_push(self, phone, amount, reference):
        if not self.enabled(): raise RuntimeError("M-Pesa is not configured.")
        phone = phone.strip().replace("+", "")
        if phone.startswith("0"): phone="254"+phone[1:]
        if not phone.startswith("254") or len(phone) != 12: raise ValueError("Use a Kenyan M-Pesa number such as 2547XXXXXXXX.")
        ts=datetime.now().strftime("%Y%m%d%H%M%S")
        password=base64.b64encode(f"{settings.MPESA_SHORTCODE}{settings.MPESA_PASSKEY}{ts}".encode()).decode()
        payload={"BusinessShortCode":settings.MPESA_SHORTCODE,"Password":password,"Timestamp":ts,"TransactionType":"CustomerPayBillOnline","Amount":int(amount),"PartyA":phone,"PartyB":settings.MPESA_SHORTCODE,"PhoneNumber":phone,"CallBackURL":settings.MPESA_CALLBACK_URL,"AccountReference":reference[:12],"TransactionDesc":"Marketplace payment"}
        r=requests.post(self.base_url+"/mpesa/stkpush/v1/processrequest",headers={"Authorization":"Bearer "+self.token()},json=payload,timeout=30); r.raise_for_status(); return r.json()

class MpesaDisbursementGateway(MpesaGateway):
    def enabled(self):
        return super().enabled() and bool(getattr(settings, "MPESA_INITIATOR_NAME", "") and getattr(settings, "MPESA_SECURITY_CREDENTIAL", "") and getattr(settings, "MPESA_QUEUE_TIMEOUT_URL", "") and getattr(settings, "MPESA_RESULT_URL", ""))
    def payout(self, phone, amount, remarks, occasion="Marketplace release"):
        if not self.enabled(): raise RuntimeError("M-Pesa B2C disbursement is not configured.")
        payload={"InitiatorName":settings.MPESA_INITIATOR_NAME,"SecurityCredential":settings.MPESA_SECURITY_CREDENTIAL,"CommandID":"BusinessPayment","Amount":int(amount),"PartyA":settings.MPESA_SHORTCODE,"PartyB":phone,"Remarks":remarks[:100],"QueueTimeOutURL":settings.MPESA_QUEUE_TIMEOUT_URL,"ResultURL":settings.MPESA_RESULT_URL,"Occasion":occasion[:100]}
        r=requests.post(self.base_url+"/mpesa/b2c/v3/paymentrequest",headers={"Authorization":"Bearer "+self.token()},json=payload,timeout=30); r.raise_for_status(); return r.json()

class PayPalGateway:
    def enabled(self):
        return bool(getattr(settings, "PAYPAL_ENABLED", False) and settings.PAYPAL_CLIENT_ID and settings.PAYPAL_CLIENT_SECRET and settings.PAYPAL_RETURN_URL and settings.PAYPAL_CANCEL_URL)
    @property
    def base_url(self):
        return 'https://api-m.paypal.com' if settings.PAYPAL_ENVIRONMENT == 'production' else 'https://api-m.sandbox.paypal.com'
    def token(self):
        r=requests.post(self.base_url+'/v1/oauth2/token', auth=(settings.PAYPAL_CLIENT_ID, settings.PAYPAL_CLIENT_SECRET), data={'grant_type':'client_credentials'}, headers={'Accept':'application/json','Accept-Language':'en_US'}, timeout=20)
        r.raise_for_status(); return r.json()['access_token']
    def create_order(self, amount, reference):
        if not self.enabled(): raise RuntimeError('PayPal is not configured.')
        r=requests.post(self.base_url+'/v2/checkout/orders', headers={'Authorization':'Bearer '+self.token(),'Content-Type':'application/json','PayPal-Request-Id':reference}, json={'intent':'CAPTURE','purchase_units':[{'reference_id':reference,'amount':{'currency_code':settings.PAYPAL_CURRENCY,'value':f'{amount:.2f}'}}],'application_context':{'return_url':settings.PAYPAL_RETURN_URL,'cancel_url':settings.PAYPAL_CANCEL_URL,'user_action':'PAY_NOW'}}, timeout=30)
        r.raise_for_status(); return r.json()
    def capture_order(self, order_id):
        r=requests.post(self.base_url+f'/v2/checkout/orders/{order_id}/capture', headers={'Authorization':'Bearer '+self.token(),'Content-Type':'application/json'}, timeout=30)
        r.raise_for_status(); return r.json()
    def verify_webhook(self, headers, event):
        if not settings.PAYPAL_WEBHOOK_ID: return False
        payload={'auth_algo':headers.get('PAYPAL-AUTH-ALGO'),'cert_url':headers.get('PAYPAL-CERT-URL'),'transmission_id':headers.get('PAYPAL-TRANSMISSION-ID'),'transmission_sig':headers.get('PAYPAL-TRANSMISSION-SIG'),'transmission_time':headers.get('PAYPAL-TRANSMISSION-TIME'),'webhook_id':settings.PAYPAL_WEBHOOK_ID,'webhook_event':event}
        r=requests.post(self.base_url+'/v1/notifications/verify-webhook-signature',headers={'Authorization':'Bearer '+self.token(),'Content-Type':'application/json'},json=payload,timeout=20); r.raise_for_status()
        return r.json().get('verification_status') == 'SUCCESS'
