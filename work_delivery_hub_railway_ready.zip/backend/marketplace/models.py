from decimal import Decimal, ROUND_HALF_UP
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.utils import timezone

MONEY_ZERO = Decimal("0.00")

class User(AbstractUser):
    ROLE_CHOICES = [("CUSTOMER", "Customer"), ("COMPANY", "Company"), ("RIDER", "Rider"), ("MANAGER", "Manager")]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="CUSTOMER")
    phone = models.CharField(max_length=30, unique=True)
    town_location = models.CharField(max_length=120)
    town = models.CharField(max_length=120)
    id_number = models.CharField(max_length=100, unique=True)
    id_document = models.FileField(upload_to="identity/%Y/%m/")
    profile_photo = models.ImageField(upload_to="profiles/%Y/%m/")
    is_identity_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.get_full_name() or self.username


class PlatformSetting(models.Model):
    platform_fee_percent = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("5.00"), validators=[MinValueValidator(Decimal("0.00")), MaxValueValidator(Decimal("100.00"))])
    updated_at = models.DateTimeField(auto_now=True)
    updated_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="platform_fee_changes")

    class Meta:
        verbose_name = "Platform setting"
        verbose_name_plural = "Platform settings"

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def current_fee_percent(cls):
        obj = cls.objects.filter(pk=1).first()
        if obj:
            return obj.platform_fee_percent
        return Decimal(str(getattr(settings, "PLATFORM_FEE_PERCENT", "5")))

    @classmethod
    def calculate_fee(cls, gross_amount):
        gross = Decimal(gross_amount).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        return (gross * cls.current_fee_percent() / Decimal("100")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


class PlatformFeeChange(models.Model):
    old_percent = models.DecimalField(max_digits=5, decimal_places=2)
    new_percent = models.DecimalField(max_digits=5, decimal_places=2)
    changed_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="platform_fee_audits")
    changed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-changed_at"]

class CompanyProfile(models.Model):
    STATUS = [("PENDING", "Pending"), ("APPROVED", "Approved"), ("REJECTED", "Rejected")]
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="company_profile")
    business_name = models.CharField(max_length=180)
    description = models.TextField(blank=True)
    address = models.CharField(max_length=255)
    logo = models.ImageField(upload_to="companies/logos/%Y/%m/", blank=True)
    status = models.CharField(max_length=20, choices=STATUS, default="PENDING")
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="approved_companies")
    created_at = models.DateTimeField(auto_now_add=True)

    @property
    def approved(self):
        return self.status == "APPROVED"

    def __str__(self):
        return self.business_name

class RiderProfile(models.Model):
    STATUS = [("PENDING", "Pending"), ("APPROVED", "Approved"), ("REJECTED", "Rejected")]
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="rider_profile")
    vehicle_type = models.CharField(max_length=80)
    license_number = models.CharField(max_length=100, blank=True)
    current_lat = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    current_lng = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    location_updated_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS, default="PENDING")
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="approved_riders")
    created_at = models.DateTimeField(auto_now_add=True)

    @property
    def is_approved(self):
        return self.status == "APPROVED"

    def __str__(self):
        return f"{self.user} - {self.status}"

class MenuItem(models.Model):
    company = models.ForeignKey(CompanyProfile, on_delete=models.CASCADE, related_name="menu_items")
    name = models.CharField(max_length=180)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    image = models.ImageField(upload_to="dishes/%Y/%m/", blank=True)
    available = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ["name"]
    def __str__(self): return self.name

class Order(models.Model):
    STATUS = [(x, x.replace("_", " ").title()) for x in ["PENDING", "PAID", "ACCEPTED", "PREPARING", "READY", "PICKED_UP", "DELIVERED", "RECEIVED", "CANCELLED"]]
    customer = models.ForeignKey(User, on_delete=models.PROTECT, related_name="orders")
    company = models.ForeignKey(CompanyProfile, on_delete=models.PROTECT, related_name="orders")
    delivery_address = models.CharField(max_length=255)
    delivery_lat = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    delivery_lng = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    delivery_phone = models.CharField(max_length=30, blank=True)
    notes = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS, default="PENDING")
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=MONEY_ZERO)
    platform_fee = models.DecimalField(max_digits=12, decimal_places=2, default=MONEY_ZERO)
    total = models.DecimalField(max_digits=12, decimal_places=2, default=MONEY_ZERO)
    created_at = models.DateTimeField(auto_now_add=True)

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    menu_item = models.ForeignKey(MenuItem, on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)

class Delivery(models.Model):
    STATUS = [(x, x.replace("_", " ").title()) for x in ["ASSIGNED", "PICKED_UP", "IN_TRANSIT", "DELIVERED"]]
    order = models.OneToOneField(Order, on_delete=models.CASCADE, related_name="delivery")
    rider = models.ForeignKey(User, on_delete=models.PROTECT, related_name="deliveries")
    status = models.CharField(max_length=20, choices=STATUS, default="ASSIGNED")
    current_lat = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    current_lng = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    location_updated_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

class Job(models.Model):
    STATUS = [(x, x.replace("_", " ").title()) for x in ["OPEN", "AWARDED", "IN_PROGRESS", "SUBMITTED", "COMPLETED", "CANCELLED"]]
    poster = models.ForeignKey(User, on_delete=models.PROTECT, related_name="posted_jobs")
    title = models.CharField(max_length=200)
    description = models.TextField()
    location = models.CharField(max_length=255)
    is_online = models.BooleanField(default=False)
    amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("1.00"))])
    status = models.CharField(max_length=20, choices=STATUS, default="OPEN")
    assigned_to = models.ForeignKey(User, null=True, blank=True, on_delete=models.PROTECT, related_name="assigned_jobs")
    awarded_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Bid(models.Model):
    STATUS = [("PENDING", "Pending"), ("ACCEPTED", "Accepted"), ("REJECTED", "Rejected")]
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name="bids")
    bidder = models.ForeignKey(User, on_delete=models.PROTECT, related_name="bids")
    proposed_amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("1.00"))])
    message = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS, default="PENDING")
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["job", "bidder"], name="one_bid_per_job_user")]

class JobSubmission(models.Model):
    job = models.OneToOneField(Job, on_delete=models.CASCADE, related_name="submission")
    worker = models.ForeignKey(User, on_delete=models.PROTECT, related_name="submissions")
    text = models.TextField(blank=True)
    file = models.FileField(upload_to="job_submissions/%Y/%m/", blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)
    approved_at = models.DateTimeField(null=True, blank=True)

class Transaction(models.Model):
    TYPES = [("JOB", "Job"), ("ORDER", "Food order")]
    STATUS = [(x, x.title()) for x in ["PENDING", "PAID", "RELEASED", "FAILED", "REFUNDED"]]
    reference = models.CharField(max_length=80, unique=True)
    transaction_type = models.CharField(max_length=20, choices=TYPES)
    payer = models.ForeignKey(User, on_delete=models.PROTECT, related_name="payments_made")
    payee = models.ForeignKey(User, null=True, blank=True, on_delete=models.PROTECT, related_name="payments_received")
    order = models.OneToOneField(Order, null=True, blank=True, on_delete=models.PROTECT, related_name="transaction")
    job = models.OneToOneField(Job, null=True, blank=True, on_delete=models.PROTECT, related_name="transaction")
    gross_amount = models.DecimalField(max_digits=12, decimal_places=2)
    platform_fee = models.DecimalField(max_digits=12, decimal_places=2)
    net_amount = models.DecimalField(max_digits=12, decimal_places=2)
    provider = models.CharField(max_length=30, default="MPESA")
    paypal_order_id = models.CharField(max_length=120, blank=True, db_index=True)
    provider_reference = models.CharField(max_length=120, blank=True)
    status = models.CharField(max_length=20, choices=STATUS, default="PENDING")
    payout_status = models.CharField(max_length=20, choices=[("NOT_STARTED","Not started"),("PENDING","Pending"),("PAID","Paid"),("FAILED","Failed")], default="NOT_STARTED")
    payout_reference = models.CharField(max_length=120, blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    paid_at = models.DateTimeField(null=True, blank=True)
    released_at = models.DateTimeField(null=True, blank=True)

    @classmethod
    def create_for(cls, *, payer, gross_amount, transaction_type, job=None, order=None, payee=None, platform_fee=None):
        gross = Decimal(gross_amount).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        fee = (PlatformSetting.calculate_fee(gross) if platform_fee is None else Decimal(platform_fee).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
        if fee < MONEY_ZERO or fee > gross:
            raise ValueError("Platform fee must be between zero and the transaction gross amount.")
        ref = f"TXN-{timezone.now().strftime('%Y%m%d%H%M%S%f')}"
        return cls.objects.create(reference=ref, payer=payer, payee=payee, gross_amount=gross, platform_fee=fee,
                                  net_amount=gross-fee, transaction_type=transaction_type, job=job, order=order)


class Rating(models.Model):
    KIND_CHOICES = [("ORDER_RIDER", "Food delivery rider"), ("ORDER_COMPANY", "Food company"), ("JOB_WORKER", "Job worker"), ("JOB_POSTER", "Job poster")]
    rater = models.ForeignKey(User, on_delete=models.PROTECT, related_name="ratings_given")
    rated = models.ForeignKey(User, on_delete=models.PROTECT, related_name="ratings_received")
    order = models.ForeignKey(Order, null=True, blank=True, on_delete=models.PROTECT, related_name="ratings")
    job = models.ForeignKey(Job, null=True, blank=True, on_delete=models.PROTECT, related_name="ratings")
    kind = models.CharField(max_length=20, choices=KIND_CHOICES)
    score = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    comment = models.TextField(blank=True, max_length=1000)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["rater", "order", "kind"], name="unique_order_rating_by_kind"),
            models.UniqueConstraint(fields=["rater", "job", "kind"], name="unique_job_rating_by_kind"),
        ]
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.rater} -> {self.rated}: {self.score}/5"


class ApiToken(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="api_tokens")
    token_hash = models.CharField(max_length=64, unique=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_used_at = models.DateTimeField(null=True, blank=True)
    revoked_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True, db_index=True)

class Notification(models.Model):
    CHANNELS = [("IN_APP", "In app"), ("SMS", "SMS"), ("EMAIL", "Email")]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="notifications")
    title = models.CharField(max_length=200)
    message = models.TextField()
    channel = models.CharField(max_length=20, choices=CHANNELS, default="IN_APP")
    read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    metadata = models.JSONField(default=dict, blank=True)
    class Meta:
        ordering = ["-created_at"]
