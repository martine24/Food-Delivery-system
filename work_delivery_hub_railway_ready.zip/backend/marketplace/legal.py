from django.views.generic import TemplateView

class PrivacyPolicyView(TemplateView):
    template_name = "marketplace/privacy.html"

class TermsView(TemplateView):
    template_name = "marketplace/terms.html"

class RefundPolicyView(TemplateView):
    template_name = "marketplace/refunds.html"
