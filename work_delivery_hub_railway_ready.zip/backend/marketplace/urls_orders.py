from django.urls import path
from . import views
urlpatterns=[
 path("<int:pk>/take/",views.take_delivery,name="take_delivery"),
 path("<int:pk>/status/",views.update_delivery,name="update_delivery"),
 path("<int:pk>/track/",views.order_tracking,name="order_tracking"),
 path("<int:pk>/received/",views.confirm_delivery_received,name="confirm_delivery_received"),
 path("<int:pk>/rate/",views.rate_order,name="rate_order"),
 path("<int:pk>/tracking-data/",views.order_tracking_data,name="order_tracking_data"),
 path("delivery/<int:pk>/location/",views.update_rider_location,name="update_rider_location"),
]
