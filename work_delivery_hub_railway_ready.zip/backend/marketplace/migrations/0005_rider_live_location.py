from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [("marketplace", "0004_commercial_completion_ratings")]
    operations = [
        migrations.AddField(model_name="riderprofile", name="current_lat", field=models.DecimalField(blank=True, decimal_places=7, max_digits=10, null=True)),
        migrations.AddField(model_name="riderprofile", name="current_lng", field=models.DecimalField(blank=True, decimal_places=7, max_digits=10, null=True)),
        migrations.AddField(model_name="riderprofile", name="location_updated_at", field=models.DateTimeField(blank=True, null=True)),
    ]
