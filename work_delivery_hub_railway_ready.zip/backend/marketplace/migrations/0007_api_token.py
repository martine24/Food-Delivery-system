from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    dependencies = [("marketplace", "0006_paypal_notifications")]
    operations = [migrations.CreateModel(
        name="ApiToken",
        fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("token_hash", models.CharField(db_index=True, max_length=64, unique=True)),
            ("created_at", models.DateTimeField(auto_now_add=True)),
            ("last_used_at", models.DateTimeField(blank=True, null=True)),
            ("revoked_at", models.DateTimeField(blank=True, null=True)),
            ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="api_tokens", to="marketplace.user")),
        ],
    )]
