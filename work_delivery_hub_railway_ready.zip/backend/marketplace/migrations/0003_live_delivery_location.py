from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [("marketplace", "0002_transaction_payout")]
    operations = [
        migrations.AddField(model_name="user", name="town", field=models.CharField(default="Nairobi", max_length=120), preserve_default=False),
        migrations.AddField(model_name="order", name="delivery_phone", field=models.CharField(blank=True, max_length=30)),
        migrations.AddField(model_name="order", name="delivery_lat", field=models.DecimalField(blank=True, decimal_places=7, max_digits=10, null=True)),
        migrations.AddField(model_name="order", name="delivery_lng", field=models.DecimalField(blank=True, decimal_places=7, max_digits=10, null=True)),
        migrations.AddField(model_name="delivery", name="location_updated_at", field=models.DateTimeField(blank=True, null=True)),
    ]
