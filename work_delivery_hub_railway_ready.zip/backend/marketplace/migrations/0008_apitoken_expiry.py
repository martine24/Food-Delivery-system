from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies=[("marketplace","0007_api_token")]
    operations=[migrations.AddField(model_name="apitoken",name="expires_at",field=models.DateTimeField(blank=True,db_index=True,null=True))]
