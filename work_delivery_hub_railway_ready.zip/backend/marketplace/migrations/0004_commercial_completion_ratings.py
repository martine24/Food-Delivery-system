from django.conf import settings
from django.db import migrations, models
import django.core.validators
import django.db.models.deletion

class Migration(migrations.Migration):
    dependencies = [("marketplace", "0003_live_delivery_location")]
    operations = [
        migrations.AlterField(model_name="order", name="status", field=models.CharField(choices=[("PENDING","Pending"),("PAID","Paid"),("ACCEPTED","Accepted"),("PREPARING","Preparing"),("READY","Ready"),("PICKED_UP","Picked Up"),("DELIVERED","Delivered"),("RECEIVED","Received"),("CANCELLED","Cancelled")], default="PENDING", max_length=20)),
        migrations.AddField(model_name="user", name="town_location", field=models.CharField(default="", max_length=120), preserve_default=False),
        migrations.AddField(model_name="delivery", name="completed_at", field=models.DateTimeField(blank=True, null=True)),
        migrations.CreateModel(
            name="Rating",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("kind", models.CharField(choices=[("ORDER_RIDER","Food delivery rider"),("ORDER_COMPANY","Food company"),("JOB_WORKER","Job worker"),("JOB_POSTER","Job poster")], max_length=20)),
                ("score", models.PositiveSmallIntegerField(validators=[django.core.validators.MinValueValidator(1), django.core.validators.MaxValueValidator(5)])),
                ("comment", models.TextField(blank=True, max_length=1000)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("job", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name="ratings", to="marketplace.job")),
                ("order", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name="ratings", to="marketplace.order")),
                ("rated", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="ratings_received", to=settings.AUTH_USER_MODEL)),
                ("rater", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="ratings_given", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-created_at"]},
        ),
        migrations.AddConstraint(model_name="rating", constraint=models.UniqueConstraint(fields=("rater","order","kind"), name="unique_order_rating_by_kind")),
        migrations.AddConstraint(model_name="rating", constraint=models.UniqueConstraint(fields=("rater","job","kind"), name="unique_job_rating_by_kind")),
    ]
