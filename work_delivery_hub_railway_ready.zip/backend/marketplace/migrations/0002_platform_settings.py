from django.conf import settings
from django.db import migrations, models
import django.core.validators
from decimal import Decimal
import django.db.models.deletion


def seed_setting(apps, schema_editor):
    PlatformSetting = apps.get_model('marketplace', 'PlatformSetting')
    PlatformSetting.objects.update_or_create(pk=1, defaults={'platform_fee_percent': Decimal('5.00')})

class Migration(migrations.Migration):
    dependencies = [('marketplace', '0001_initial')]
    operations = [
        migrations.CreateModel(
            name='PlatformSetting',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('platform_fee_percent', models.DecimalField(decimal_places=2, default=Decimal('5.00'), max_digits=5, validators=[django.core.validators.MinValueValidator(Decimal('0.00')), django.core.validators.MaxValueValidator(Decimal('100.00'))])),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('updated_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='platform_fee_changes', to=settings.AUTH_USER_MODEL)),
            ],
            options={'verbose_name': 'Platform setting', 'verbose_name_plural': 'Platform settings'},
        ),
        migrations.CreateModel(
            name='PlatformFeeChange',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('old_percent', models.DecimalField(decimal_places=2, max_digits=5)),
                ('new_percent', models.DecimalField(decimal_places=2, max_digits=5)),
                ('changed_at', models.DateTimeField(auto_now_add=True)),
                ('changed_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='platform_fee_audits', to=settings.AUTH_USER_MODEL)),
            ],
            options={'ordering': ['-changed_at']},
        ),
        migrations.RunPython(seed_setting, migrations.RunPython.noop),
    ]
