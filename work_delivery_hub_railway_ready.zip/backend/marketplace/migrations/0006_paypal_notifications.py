from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies=[("marketplace","0005_rider_live_location")]
    operations=[
        migrations.AddField(model_name="transaction",name="paypal_order_id",field=models.CharField(blank=True,db_index=True,max_length=120)),
        migrations.CreateModel(name="Notification",fields=[
            ("id",models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name="ID")),
            ("title",models.CharField(max_length=200)),
            ("message",models.TextField()),
            ("channel",models.CharField(choices=[("IN_APP","In app"),("SMS","SMS"),("EMAIL","Email")],default="IN_APP",max_length=20)),
            ("read",models.BooleanField(default=False)),
            ("created_at",models.DateTimeField(auto_now_add=True)),
            ("metadata",models.JSONField(blank=True,default=dict)),
            ("user",models.ForeignKey(on_delete=models.deletion.CASCADE,related_name="notifications",to="marketplace.user")),
        ], options={"ordering":["-created_at"]}),
    ]
