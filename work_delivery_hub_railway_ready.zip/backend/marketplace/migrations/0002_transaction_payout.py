from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies=[("marketplace","0001_initial")]
    operations=[migrations.AddField(model_name="transaction",name="payout_status",field=models.CharField(choices=[("NOT_STARTED","Not started"),("PENDING","Pending"),("PAID","Paid"),("FAILED","Failed")],default="NOT_STARTED",max_length=20)),migrations.AddField(model_name="transaction",name="payout_reference",field=models.CharField(blank=True,max_length=120))]
