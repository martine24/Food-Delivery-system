import hashlib, json, secrets
from decimal import Decimal
from functools import wraps
from django.contrib.auth import authenticate, get_user_model
from django.db import transaction as db_transaction
from django.http import JsonResponse
from django.utils import timezone
from django.contrib.auth.hashers import make_password
from django.core.files.uploadedfile import UploadedFile
from django.db.models import Q
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from .models import ApiToken, CompanyProfile, MenuItem, Order, OrderItem, Job, Bid, Delivery, RiderProfile, Transaction, Rating
from .payments import MpesaGateway
from .notifications import notify

User = get_user_model()


def _json(request):
    try:
        return json.loads(request.body or "{}")
    except (TypeError, ValueError):
        return None

def _out_user(u):
    return {"id":u.id,"name":u.get_full_name() or u.username,"role":u.role,"phone":u.phone,"town":u.town,"verified":u.is_identity_verified}

def _token(user):
    raw = secrets.token_urlsafe(48)
    ApiToken.objects.create(user=user, token_hash=hashlib.sha256(raw.encode()).hexdigest(), expires_at=timezone.now()+timezone.timedelta(days=30))
    return raw

def api_auth(view):
    @wraps(view)
    def wrapped(request, *args, **kwargs):
        header = request.headers.get("Authorization", "")
        if not header.startswith("Token "):
            return JsonResponse({"detail":"Authentication required."}, status=401)
        raw = header[6:].strip()
        if not raw:
            return JsonResponse({"detail":"Authentication required."}, status=401)
        h = hashlib.sha256(raw.encode()).hexdigest()
        token = ApiToken.objects.select_related("user").filter(token_hash=h, revoked_at__isnull=True).filter(Q(expires_at__isnull=True)|Q(expires_at__gt=timezone.now())).first()
        if not token or not token.user.is_active:
            return JsonResponse({"detail":"Invalid or revoked token."}, status=401)
        token.last_used_at = timezone.now(); token.save(update_fields=["last_used_at"])
        request.api_user = token.user
        return view(request, *args, **kwargs)
    return csrf_exempt(wrapped)

def _err(message, status=400): return JsonResponse({"detail":message}, status=status)
def _decimal(v):
    try:
        x=Decimal(str(v)); return x if x.is_finite() else None
    except Exception: return None

def _menu(m):
    return {"id":m.id,"name":m.name,"description":m.description,"price":str(m.price),"imageUrl":m.image.url if m.image else None,"available":m.available}

def _company(c):
    return {"id":c.id,"name":c.business_name,"description":c.description,"address":c.address,"logoUrl":c.logo.url if c.logo else None,"dishes":[_menu(m) for m in c.menu_items.filter(available=True)]}

def _order(o, viewer=None):
    d=getattr(o,"delivery",None); rider=d.rider if d else None
    is_customer = bool(viewer and viewer.id == o.customer_id)
    is_assigned_rider = bool(viewer and d and viewer.id == d.rider_id)
    is_company = bool(viewer and hasattr(viewer, "company_profile") and o.company.user_id == viewer.id)
    expose_destination = is_customer or is_assigned_rider or is_company
    expose_rider_location = bool(d and o.status != "RECEIVED" and d.status in {"ASSIGNED","PICKED_UP","IN_TRANSIT"} and (is_customer or is_assigned_rider))
    return {
        "id":o.id,"companyName":o.company.business_name,"status":o.status,"subtotal":str(o.subtotal),
        "platformFee":str(o.platform_fee),"total":str(o.total),
        "deliveryAddress":o.delivery_address if expose_destination else None,
        "deliveryLat":float(o.delivery_lat) if expose_destination and o.delivery_lat is not None else None,
        "deliveryLng":float(o.delivery_lng) if expose_destination and o.delivery_lng is not None else None,
        "riderName":(rider.get_full_name() or rider.username) if (rider and (is_customer or is_assigned_rider or is_company)) else None,
        "riderLat":float(d.current_lat) if expose_rider_location and d.current_lat is not None else None,
        "riderLng":float(d.current_lng) if expose_rider_location and d.current_lng is not None else None,
        "transactionReference":(o.transaction.reference if hasattr(o,"transaction") and o.transaction.status=="PENDING" and is_customer else None)
    }

def _job(j): return {"id":j.id,"title":j.title,"description":j.description,"location":j.location,"online":j.is_online,"amount":str(j.amount),"status":j.status,"posterName":j.poster.get_full_name() or j.poster.username}

@csrf_exempt
def register_api(request):
    if request.method != "POST": return _err("POST required",405)
    data=_json(request) or {}
    role=str(data.get("role","CUSTOMER")).upper().strip()
    if role not in {"CUSTOMER","RIDER","COMPANY"}: return _err("Invalid registration role.")
    required=["username","password","phone","town","townLocation","idNumber"]
    if any(not str(data.get(k,"" )).strip() for k in required): return _err("Username, password, phone, town, town location and ID number are required.")
    password=str(data.get("password"))
    if len(password)<10: return _err("Password must be at least 10 characters.")
    if User.objects.filter(username=data["username"]).exists(): return _err("Username is already in use.",409)
    if User.objects.filter(phone=data["phone"]).exists(): return _err("Phone number is already in use.",409)
    if User.objects.filter(id_number=data["idNumber"]).exists(): return _err("ID number is already registered.",409)
    # Identity uploads are mandatory for every account type.
    id_document=request.FILES.get("idDocument"); profile_photo=request.FILES.get("profilePhoto")
    if not id_document or not profile_photo: return _err("ID document and profile photo are required.")
    from .forms import validate_upload
    try:
        validate_upload(id_document); validate_upload(profile_photo,image=True)
    except Exception as exc: return _err(str(exc))
    with db_transaction.atomic():
        u=User.objects.create_user(username=str(data["username"]).strip(),password=password,first_name=str(data.get("firstName","")).strip(),last_name=str(data.get("lastName","")).strip(),email=str(data.get("email","")).strip(),phone=str(data["phone"]).strip(),town=str(data["town"]).strip(),town_location=str(data["townLocation"]).strip(),id_number=str(data["idNumber"]).strip(),id_document=id_document,profile_photo=profile_photo,role=role,is_identity_verified=False)
        if role=="RIDER":
            RiderProfile.objects.create(user=u,vehicle_type=str(data.get("vehicleType","Bike")).strip() or "Bike",license_number=str(data.get("licenseNumber","")).strip())
        elif role=="COMPANY":
            CompanyProfile.objects.create(user=u,business_name=str(data.get("businessName","")).strip() or u.get_full_name() or u.username,description=str(data.get("description","")).strip(),address=str(data.get("address","")).strip() or str(data["townLocation"]).strip())
        token=_token(u)
    return JsonResponse({"token":token,"user":_out_user(u)},status=201)

@api_auth
def logout_api(request):
    if request.method!="POST": return _err("POST required",405)
    raw=request.headers.get("Authorization","")[6:].strip()
    ApiToken.objects.filter(token_hash=hashlib.sha256(raw.encode()).hexdigest(),revoked_at__isnull=True).update(revoked_at=timezone.now())
    return JsonResponse({"success":True,"message":"Signed out."})

@csrf_exempt
def login_api(request):
    if request.method != "POST": return _err("POST required",405)
    data=_json(request)
    if not data: return _err("Invalid JSON")
    ident=str(data.get("username","")).strip(); password=str(data.get("password","") )
    user=authenticate(request, username=ident, password=password)
    if user is None and "@" in ident:
        u=User.objects.filter(email__iexact=ident).first()
        if u: user=authenticate(request, username=u.username, password=password)
    if user is None: return _err("Invalid username or password.",401)
    return JsonResponse({"token":_token(user),"user":_out_user(user)})

@api_auth
def me(request): return JsonResponse(_out_user(request.api_user))

@api_auth
def companies(request):
    if request.method != "GET": return _err("GET required",405)
    return JsonResponse([_company(c) for c in CompanyProfile.objects.filter(status="APPROVED").prefetch_related("menu_items")], safe=False)

@api_auth
def orders_api(request):
    u=request.api_user
    if request.method == "GET":
        return JsonResponse([_order(o,u) for o in u.orders.select_related("company","delivery","delivery__rider").prefetch_related("items")],safe=False)
    if request.method != "POST" or u.role != "CUSTOMER": return _err("Only customers can create orders.",403)
    data=_json(request)
    if not data: return _err("Invalid JSON")
    company=CompanyProfile.objects.filter(pk=data.get("companyId"),status="APPROVED").first()
    if not company: return _err("Company is not available.")
    address=str(data.get("deliveryAddress","")).strip(); phone=str(data.get("deliveryPhone","")).strip() or u.phone
    lat=_decimal(data.get("latitude")); lng=_decimal(data.get("longitude"))
    if not address or lat is None or lng is None or not (-90<=lat<=90 and -180<=lng<=180): return _err("Delivery address and valid live GPS coordinates are required.")
    items=data.get("items") or []
    if not isinstance(items,list) or not items: return _err("Select at least one available dish.")
    ids=[]; subtotal=Decimal("0.00")
    for row in items:
        try: iid=int(row.get("menuItemId")); q=int(row.get("quantity"))
        except Exception: return _err("Invalid item quantity.")
        if q<1 or q>99: return _err("Quantities must be whole numbers from 1 to 99.")
        ids.append((iid,q))
    menus={m.id:m for m in MenuItem.objects.filter(company=company,available=True,id__in=[i for i,_ in ids])}
    if len(menus)!=len(set(i for i,_ in ids)): return _err("One or more selected dishes are unavailable.")
    with db_transaction.atomic():
        for iid,q in ids: subtotal += menus[iid].price*q
        fee=PlatformSetting.calculate_fee(subtotal); total=subtotal+fee
        o=Order.objects.create(customer=u,company=company,delivery_address=address,delivery_phone=phone,delivery_lat=lat,delivery_lng=lng,notes=str(data.get("notes","")).strip(),subtotal=subtotal,platform_fee=fee,total=total,status="PENDING")
        for iid,q in ids: OrderItem.objects.create(order=o,menu_item=menus[iid],quantity=q,unit_price=menus[iid].price)
        Transaction.create_for(payer=u,gross_amount=total,platform_fee=o.platform_fee,transaction_type="ORDER",order=o,payee=company.user)
    return JsonResponse(_order(o,u),status=201)

@api_auth
def jobs_api(request):
    if request.method=="GET": return JsonResponse([_job(j) for j in Job.objects.filter(status="OPEN").select_related("poster")],safe=False)
    if request.method=="POST":
        u=request.api_user
        if u.role not in {"CUSTOMER","COMPANY"}: return _err("Only customers and companies can post jobs.",403)
        d=_json(request) or {}
        title=str(d.get("title","")).strip(); desc=str(d.get("description","")).strip(); loc=str(d.get("location","")).strip(); amount=_decimal(d.get("amount"))
        if not title or not desc or not loc or amount is None or amount<1: return _err("Title, description, location and amount are required.")
        j=Job.objects.create(poster=u,title=title,description=desc,location=loc,is_online=bool(d.get("online")),amount=amount)
        return JsonResponse(_job(j),status=201)
    return _err("Unsupported method",405)

@api_auth
def bid_api(request, pk):
    if request.method!="POST": return _err("POST required",405)
    u=request.api_user; j=Job.objects.filter(pk=pk).first()
    if not j: return _err("Job not found.",404)
    if j.poster_id==u.id: return _err("You cannot bid on your own job.")
    if j.status!="OPEN": return _err("This job is no longer open.")
    d=_json(request) or {}; amount=_decimal(d.get("amount")); message=str(d.get("message","")).strip()
    if amount is None or amount<1 or not message: return _err("Bid amount and message are required.")
    bid,created=Bid.objects.get_or_create(job=j,bidder=u,defaults={"proposed_amount":amount,"message":message})
    if not created: return _err("You have already bid on this job.")
    return JsonResponse({"success":True,"message":"Bid submitted.","reference":str(bid.id)},status=201)

@api_auth
def payment_status_api(request, reference):
    if request.method!="GET": return _err("GET required",405)
    tx=Transaction.objects.select_related("order","job").filter(reference=reference,payer=request.api_user).first()
    if not tx: return _err("Transaction not found.",404)
    return JsonResponse({"reference":tx.reference,"status":tx.status,"payoutStatus":tx.payout_status,"paidAt":tx.paid_at.isoformat() if tx.paid_at else None,"orderId":tx.order_id,"jobId":tx.job_id})

@api_auth
def company_orders_api(request):
    u=request.api_user
    if u.role!="COMPANY" or not hasattr(u,"company_profile") or not u.company_profile.approved: return _err("Approved company access required.",403)
    if request.method=="GET":
        qs=Order.objects.filter(company=u.company_profile).select_related("company","customer","delivery","delivery__rider").order_by("-created_at")[:100]
        return JsonResponse([_order(o,u) for o in qs],safe=False)
    if request.method!="POST": return _err("GET or POST required",405)
    d=_json(request) or {}; oid=d.get("orderId"); status=str(d.get("status","")).upper()
    allowed={"PAID":"PREPARING","PREPARING":"READY"}
    o=Order.objects.select_for_update().filter(pk=oid,company=u.company_profile).first()
    if not o: return _err("Order not found.",404)
    expected=allowed.get(o.status)
    if status!=expected: return _err(f"Invalid order transition. Expected {expected or 'none'}.")
    with db_transaction.atomic():
        o.status=status; o.save(update_fields=["status"])
    return JsonResponse(_order(o,u))

@api_auth
def rider_orders(request):
    u=request.api_user
    if u.role!="RIDER" or not hasattr(u,"rider_profile") or not u.rider_profile.is_approved: return _err("Approved rider access required.",403)
    if request.method!="GET": return _err("GET required",405)
    orders=Order.objects.filter(status="READY",delivery__isnull=True).select_related("company","delivery")
    mine=Order.objects.filter(delivery__rider=u).select_related("company","delivery","delivery__rider")
    return JsonResponse([_order(o,u) for o in list(orders)+list(mine)],safe=False)

@api_auth
@csrf_exempt
def accept_delivery(request,pk):
    if request.method!="POST": return _err("POST required",405)
    u=request.api_user
    if u.role!="RIDER" or not hasattr(u,"rider_profile") or not u.rider_profile.is_approved: return _err("Approved rider access required.",403)
    d=_json(request) or {}; lat=_decimal(d.get("latitude")); lng=_decimal(d.get("longitude"))
    if lat is None or lng is None or not (-90<=lat<=90 and -180<=lng<=180): return _err("Current rider GPS is required before acceptance.")
    with db_transaction.atomic():
        o=Order.objects.select_for_update().filter(pk=pk,status="READY",delivery__isnull=True).first()
        if not o: return _err("Order is no longer available.",409)
        if o.delivery_lat is not None and o.delivery_lng is not None:
            from .views import _distance_km
            distance = _distance_km(lat, lng, o.delivery_lat, o.delivery_lng)
            if distance > float(settings.RIDER_MAX_DELIVERY_DISTANCE_KM):
                return _err(f"You are about {distance:.1f} km from the delivery point. Move closer before accepting this order.")
        now=timezone.now()
        delivery=Delivery.objects.create(order=o,rider=u,status="ASSIGNED",current_lat=lat,current_lng=lng,location_updated_at=now)
        o.status="PICKED_UP"; o.save(update_fields=["status"])
        RiderProfile.objects.filter(user=u).update(current_lat=lat,current_lng=lng,location_updated_at=now)
    notify(o.customer, "Your order has been picked up", f"Order #{o.id} from {o.company.business_name} has been picked up by a delivery rider.", metadata={"order_id":o.id,"event":"ORDER_PICKED_UP"})
    return JsonResponse({"success":True,"message":"Delivery accepted and customer notified.","reference":str(delivery.id)})

@api_auth
def rider_location(request):
    if request.method!="POST": return _err("POST required",405)
    u=request.api_user; d=_json(request) or {}; lat=_decimal(d.get("latitude")); lng=_decimal(d.get("longitude"))
    if u.role!="RIDER" or not hasattr(u,"rider_profile") or not u.rider_profile.is_approved: return _err("Approved rider access required.",403)
    if lat is None or lng is None or not (-90<=lat<=90 and -180<=lng<=180): return _err("Valid GPS coordinates required.")
    active=Delivery.objects.filter(rider=u,status__in=["ASSIGNED","PICKED_UP","IN_TRANSIT"]).first()
    if not active:
        RiderProfile.objects.filter(user=u).update(current_lat=None,current_lng=None,location_updated_at=None)
        return _err("Live GPS updates are only accepted while you have an active delivery.",409)
    now=timezone.now()
    Delivery.objects.filter(pk=active.pk).update(current_lat=lat,current_lng=lng,location_updated_at=now)
    RiderProfile.objects.filter(user=u).update(current_lat=lat,current_lng=lng,location_updated_at=now)
    return JsonResponse({"success":True,"message":"Location updated."})

@api_auth
def notifications_api(request):
    if request.method!="GET": return _err("GET required",405)
    from .models import Notification
    rows=Notification.objects.filter(user=request.api_user).values("id","title","message","channel","read","created_at","metadata")[:100]
    return JsonResponse([{**x,"created_at":x["created_at"].isoformat()} for x in rows],safe=False)

@api_auth
def tracking_api(request,pk):
    u=request.api_user; o=Order.objects.select_related("company","customer","delivery","delivery__rider").filter(pk=pk).first()
    if not o: return _err("Order not found.",404)
    d=getattr(o,"delivery",None)
    if u.id not in {o.customer_id, d.rider_id if d else None}: return _err("Forbidden",403)
    if d and o.status!="RECEIVED" and d.status in {"ASSIGNED","PICKED_UP","IN_TRANSIT"}: return JsonResponse(_order(o,u))
    return JsonResponse(_order(o,u))

@api_auth
def mpesa_api(request):
    if request.method!="POST": return _err("POST required",405)
    u=request.api_user; d=_json(request) or {}; ref=str(d.get("transactionReference","")).strip(); phone=str(d.get("phone","")).strip()
    tx=Transaction.objects.select_related("order").filter(reference=ref,payer=u,status="PENDING").first()
    if not tx: return _err("Pending transaction not found.",404)
    try:
        result=MpesaGateway().stk_push(phone,tx.gross_amount,tx.reference)
        tx.provider_reference=result.get("CheckoutRequestID",""); tx.metadata={**tx.metadata,"mpesa_initiation":result}; tx.save(update_fields=["provider_reference","metadata"])
        return JsonResponse({"success":True,"message":result.get("CustomerMessage","Payment request sent to your phone."),"reference":tx.reference})
    except Exception as exc: return _err(str(exc),502)

@api_auth
def receive_order(request,pk):
    if request.method!="POST": return _err("POST required",405)
    u=request.api_user
    with db_transaction.atomic():
        o=Order.objects.select_for_update().select_related("delivery").filter(pk=pk,customer=u,status="DELIVERED").first()
        if not o: return _err("Delivery is not ready for receipt confirmation.")
        d=getattr(o,"delivery",None)
        if not d or d.status!="DELIVERED": return _err("Delivery status is invalid.")
        o.status="RECEIVED"; o.save(update_fields=["status"])
        d.current_lat=d.current_lng=d.location_updated_at=None; d.completed_at=timezone.now(); d.save(update_fields=["current_lat","current_lng","location_updated_at","completed_at","updated_at"])
        RiderProfile.objects.filter(user_id=d.rider_id).update(current_lat=None,current_lng=None,location_updated_at=None)
    return JsonResponse({"success":True,"message":"Delivery received and live tracking ended."})

@api_auth
def rate_order_api(request,pk):
    if request.method!="POST": return _err("POST required",405)
    u=request.api_user; o=Order.objects.select_related("delivery","company").filter(pk=pk,customer=u,status="RECEIVED").first()
    if not o: return _err("Only received orders can be rated.")
    d=_json(request) or {}; kind=str(d.get("kind","")); score=d.get("score"); comment=str(d.get("comment","")).strip()
    if kind not in {"ORDER_RIDER","ORDER_COMPANY"}: return _err("Invalid rating kind.")
    try: score=int(score)
    except: return _err("Score must be 1 to 5.")
    if score<1 or score>5: return _err("Score must be 1 to 5.")
    rated=d.get("ratedUserId")
    if kind=="ORDER_RIDER":
        if not o.delivery: return _err("No rider to rate.")
        rated_id=o.delivery.rider_id
    else: rated_id=o.company.user_id
    if rated and int(rated)!=rated_id: return _err("Invalid rated user.")
    rating,created=Rating.objects.get_or_create(rater=u,order=o,kind=kind,defaults={"rated_id":rated_id,"score":score,"comment":comment})
    if not created: return _err("This rating already exists.",409)
    return JsonResponse({"success":True,"message":"Rating submitted."},status=201)
