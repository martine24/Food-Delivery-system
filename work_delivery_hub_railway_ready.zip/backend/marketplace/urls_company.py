from django.urls import path
from . import views
urlpatterns=[path("profile/",views.company_profile,name="company_profile"),path("menu/add/",views.add_menu_item,name="add_menu_item"),path("orders/<int:pk>/status/",views.company_order_status,name="company_order_status"),path("<int:company_id>/order/",views.create_order,name="create_order")]
