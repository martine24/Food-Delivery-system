import math
import json
import logging
from decimal import Decimal
from django.contrib import messages
from django.conf import settings
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.db import transaction as db_transaction
from django.http import JsonResponse, HttpResponseForbidden, FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from .forms import *
from .models import *


def role_required(*roles):
    def deco(view):
        @login_required
        def wrapped(request,*args,**kwargs):
            if request.user.role not in roles and not request.user.is_superuser: return HttpResponseForbidden("You do not have permission to access this page.")
            return view(request,*args,**kwargs)
        return wrapped
    return deco

@login_required
def protected_file(request, kind, pk):
    if kind in {"identity", "profile"}:
        if request.user.role != "MANAGER" and not request.user.is_superuser: return HttpResponseForbidden()
        obj = get_object_or_404(User, pk=pk); field = obj.id_document if kind == "identity" else obj.profile_photo
    elif kind == "submission":
        sub = get_object_or_404(JobSubmission, pk=pk)
        if request.user.id not in {sub.worker_id, sub.job.poster_id} and request.user.role != "MANAGER" and not request.user.is_superuser: return HttpResponseForbidden()
        field = sub.file
    else: raise Http404
    if not field: raise Http404
    return FileResponse(field.open("rb"), as_attachment=True, filename=field.name.split("/")[-1])

def home(request):
    companies=CompanyProfile.objects.filter(status="APPROVED").prefetch_related("menu_items")[:12]
    jobs=Job.objects.filter(status="OPEN").select_related("poster").order_by("-created_at")[:12]
    return render(request,"marketplace/home.html",{"companies":companies,"jobs":jobs})

def register(request):
    form=RegisterForm(request.POST or None, request.FILES or None)
    if request.method=="POST" and form.is_valid():
        user=form.save()
        if user.role=="RIDER": RiderProfile.objects.create(user=user,vehicle_type="Not specified")
        if user.role=="COMPANY": CompanyProfile.objects.create(user=user,business_name=user.get_full_name() or user.username,address="")
        login(request,user); messages.success(request,"Account created. Complete your profile and await required approval."); return redirect("dashboard")
    return render(request,"registration/register.html",{"form":form})

@login_required
def dashboard(request):
    u=request.user
    context={"orders":u.orders.select_related("company").prefetch_related("items").order_by("-created_at")[:20],"jobs":u.posted_jobs.order_by("-created_at")[:20],"bids":u.bids.select_related("job").order_by("-created_at")[:20]}
    if hasattr(u,"rider_profile"):
        context["rider"]=u.rider_profile
        context["available_orders"]=Order.objects.filter(status="READY",delivery__isnull=True).select_related("company","customer")
        context["my_deliveries"]=u.deliveries.select_related("order","order__company").order_by("-updated_at")[:20]
    if hasattr(u,"company_profile"):
        context["company"]=u.company_profile
        context["menu"]=u.company_profile.menu_items.all()
        context["company_orders"]=u.company_profile.orders.select_related("customer").prefetch_related("items").order_by("-created_at")[:30]
    return render(request,"marketplace/dashboard.html",context)

def _valid_coordinate(value, minimum, maximum):
    try:
        number = Decimal(str(value))
        if not number.is_finite() or number < Decimal(str(minimum)) or number > Decimal(str(maximum)):
            return None
        return number.quantize(Decimal("0.0000001"))
    except Exception:
        return None


@role_required("CUSTOMER")
def create_order(request,company_id):
    company=get_object_or_404(CompanyProfile,pk=company_id,status="APPROVED")
    if request.method!="POST": return redirect("home")
    form=OrderForm(request.POST)
    if not form.is_valid():
        for error in form.errors.get("__all__", []): messages.error(request, error)
        if not form.errors.get("__all__"):
            messages.error(request, "Please check the delivery address, contact details, GPS location and comments.")
        return redirect("home")
    ids=[]
    invalid_quantity=False
    for key,value in request.POST.items():
        if key.startswith("item_"):
            try:
                q=int(value); item_id=int(key.split("_",1)[1])
                if q < 0 or q > 99:
                    invalid_quantity=True
                elif q > 0:
                    ids.append((item_id,q))
            except (ValueError, TypeError):
                invalid_quantity=True
    if invalid_quantity:
        messages.error(request,"Each item quantity must be a whole number between 0 and 99.")
        return redirect("home")
    items=list(MenuItem.objects.filter(company=company,available=True,id__in=[x[0] for x in ids]))
    by_id={x.id:x for x in items}; subtotal=sum((by_id[i].price*q for i,q in ids if i in by_id),Decimal("0.00"))
    if not ids or subtotal<=0: messages.error(request,"Select at least one available dish."); return redirect("home")
    with db_transaction.atomic():
        fee=PlatformSetting.calculate_fee(subtotal); total=subtotal+fee
        order=Order.objects.create(customer=request.user,company=company,delivery_address=form.cleaned_data["delivery_address"],delivery_phone=form.cleaned_data["delivery_phone"] or request.user.phone,delivery_lat=form.cleaned_data.get("delivery_lat"),delivery_lng=form.cleaned_data.get("delivery_lng"),notes=form.cleaned_data["notes"],subtotal=subtotal,platform_fee=fee,total=total,status="PENDING")
        for item_id,q in ids:
            if item_id in by_id: OrderItem.objects.create(order=order,menu_item=by_id[item_id],quantity=q,unit_price=by_id[item_id].price)
        tx=Transaction.create_for(payer=request.user,gross_amount=total,platform_fee=order.platform_fee,transaction_type="ORDER",order=order,payee=company.user)
    return redirect("payments_checkout",transaction_ref=tx.reference)

@role_required("COMPANY")
def company_profile(request):
    profile=get_object_or_404(CompanyProfile,user=request.user)
    form=CompanyForm(request.POST or None,request.FILES or None,instance=profile)
    if request.method=="POST" and form.is_valid(): form.save(); messages.success(request,"Company profile saved."); return redirect("dashboard")
    return render(request,"marketplace/form.html",{"form":form,"title":"Company profile"})

@role_required("COMPANY")
def add_menu_item(request):
    company=get_object_or_404(CompanyProfile,user=request.user)
    form=MenuItemForm(request.POST or None,request.FILES or None)
    if form.is_valid():
        item=form.save(commit=False); item.company=company; item.save(); messages.success(request,"Dish saved. It becomes visible to customers when the company is approved."); return redirect("dashboard")
    return render(request,"marketplace/form.html",{"form":form,"title":"Add dish"})

@role_required("RIDER")
def rider_profile(request):
    profile=get_object_or_404(RiderProfile,user=request.user)
    form=RiderForm(request.POST or None,instance=profile)
    if request.method=="POST" and form.is_valid():
        p=form.save(commit=False); p.status="PENDING"; p.approved_at=None; p.approved_by=None; p.save(); messages.success(request,"Rider application updated and sent for manager review."); return redirect("dashboard")
    return render(request,"marketplace/form.html",{"form":form,"title":"Rider application"})

@login_required
def create_job(request):
    form=JobForm(request.POST or None)
    if form.is_valid():
        job=form.save(commit=False); job.poster=request.user; job.save(); messages.success(request,"Job posted and open for bids."); return redirect("job_detail",job.id)
    return render(request,"marketplace/form.html",{"form":form,"title":"Post a job"})

def job_list(request):
    return render(request,"marketplace/jobs.html",{"jobs":Job.objects.filter(status="OPEN").select_related("poster").order_by("-created_at")})


@login_required
def bid_job(request,pk):
    job=get_object_or_404(Job,pk=pk,status="OPEN")
    if job.poster_id==request.user.id: messages.error(request,"You cannot bid on your own job."); return redirect("job_detail",pk)
    if not request.user.id_document or not request.user.profile_photo: messages.error(request,"Identity document and profile photo are required before bidding."); return redirect("job_detail",pk)
    form=BidForm(request.POST or None)
    if form.is_valid():
        bid=form.save(commit=False); bid.job=job; bid.bidder=request.user
        try: bid.save()
        except Exception: messages.error(request,"You already have a bid on this job."); return redirect("job_detail",pk)
        messages.success(request,"Bid submitted."); return redirect("job_detail",pk)
    return render(request,"marketplace/form.html",{"form":form,"title":f"Bid on {job.title}"})

@login_required
def accept_bid(request,pk):
    if request.method!="POST": return HttpResponseForbidden()
    with db_transaction.atomic():
        job=get_object_or_404(Job.objects.select_for_update(),pk=pk,poster=request.user,status="OPEN")
        bid=get_object_or_404(Bid,pk=request.POST.get("bid_id"),job=job,status="PENDING")
        bid.status="ACCEPTED"; bid.save(update_fields=["status"]); Bid.objects.filter(job=job).exclude(pk=bid.pk).update(status="REJECTED")
        job.assigned_to=bid.bidder; job.amount=bid.proposed_amount; job.status="AWARDED"; job.awarded_at=timezone.now(); job.save(update_fields=["assigned_to","amount","status","awarded_at"])
        tx=Transaction.create_for(payer=request.user,gross_amount=job.amount,transaction_type="JOB",job=job,payee=bid.bidder)
    messages.success(request,"Bid accepted. Complete payment to activate the job and allow work submission.")
    return redirect("payments_checkout",transaction_ref=tx.reference)

@login_required
def submit_job(request,pk):
    job=get_object_or_404(Job,pk=pk,assigned_to=request.user,status__in=["AWARDED","IN_PROGRESS"])
    if not hasattr(job,"transaction") or job.transaction.status!="PAID": messages.error(request,"Payment has not been confirmed. Work cannot be submitted yet."); return redirect("job_detail",pk)
    form=SubmissionForm(request.POST or None,request.FILES or None)
    if form.is_valid():
        sub=form.save(commit=False); sub.job=job; sub.worker=request.user; sub.save(); job.status="SUBMITTED"; job.save(update_fields=["status"]); messages.success(request,"Work submitted for review."); return redirect("job_detail",pk)
    return render(request,"marketplace/form.html",{"form":form,"title":"Submit completed work"})

def _request_payout(tx):
    if tx.status != "PAID": return
    if not tx.payee:
        logger.error("Cannot release transaction %s: no payee", tx.reference)
        tx.payout_status="FAILED"; tx.save(update_fields=["payout_status"]); return
    from .payments import MpesaDisbursementGateway
    gateway=MpesaDisbursementGateway()
    if not gateway.enabled():
        tx.payout_status="NOT_STARTED"; tx.save(update_fields=["payout_status"]); return
    try:
        response=gateway.payout(tx.payee.phone,tx.net_amount,f"Release {tx.reference}")
        payout_reference = response.get("ConversationID") or response.get("OriginatorConversationID") or ""
        if not payout_reference:
            raise RuntimeError("M-Pesa B2C did not return a payout reference.")
        tx.payout_status="PENDING"; tx.payout_reference=payout_reference; tx.metadata={**(tx.metadata or {}),"payout_response":response}; tx.save(update_fields=["payout_status","payout_reference","metadata"])
    except Exception:
        logger.exception("M-Pesa B2C payout initiation failed for %s", tx.reference)
        tx.payout_status="FAILED"; tx.save(update_fields=["payout_status"])


@login_required
def approve_submission(request,pk):
    if request.method!="POST": return HttpResponseForbidden()
    with db_transaction.atomic():
        job=get_object_or_404(Job.objects.select_for_update(),pk=pk,poster=request.user,status="SUBMITTED")
        sub=get_object_or_404(JobSubmission,job=job)
        sub.approved_at=timezone.now(); sub.save(update_fields=["approved_at"]); job.status="COMPLETED"; job.save(update_fields=["status"])
        tx=job.transaction
        _request_payout(tx)
    messages.success(request,"Work accepted. The 5% platform fee has been recorded; provider payout status is shown on the transaction.")
    return redirect("job_detail",pk)

@csrf_exempt
def mpesa_callback(request):
    if request.method != "POST":
        return JsonResponse({"ResultCode": 1, "ResultDesc": "POST required"}, status=405)
    try:
        body = json.loads(request.body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return JsonResponse({"ResultCode": 1, "ResultDesc": "Invalid JSON"}, status=400)
    callback = body.get("Body", {}).get("stkCallback", {})
    result = callback.get("ResultCode")
    checkout_id = callback.get("CheckoutRequestID", "")
    with db_transaction.atomic():
        tx = Transaction.objects.select_for_update().filter(provider_reference=checkout_id, provider="MPESA").first()
        if not tx:
            return JsonResponse({"ResultCode": 0, "ResultDesc": "Accepted"})
        if tx.status != "PENDING":
            return JsonResponse({"ResultCode": 0, "ResultDesc": "Accepted"})
        if str(result) != "0":
            tx.status = "FAILED"; tx.metadata = body; tx.save(update_fields=["status", "metadata"])
            return JsonResponse({"ResultCode": 0, "ResultDesc": "Accepted"})
        items = callback.get("CallbackMetadata", {}).get("Item", [])
        metadata = {item.get("Name"): item.get("Value") for item in items if item.get("Name")}
        try:
            callback_amount = Decimal(str(metadata.get("Amount")))
        except (TypeError, ValueError, ArithmeticError):
            callback_amount = None
        expected_phone = (tx.payer.phone or "").replace("+", "").replace(" ", "").replace("-", "")
        callback_phone = str(metadata.get("PhoneNumber") or "").replace("+", "").replace(" ", "").replace("-", "")
        if expected_phone.startswith("0"): expected_phone = "254" + expected_phone[1:]
        if callback_phone.startswith("0"): callback_phone = "254" + callback_phone[1:]
        if callback_amount != tx.gross_amount or (expected_phone and callback_phone and expected_phone != callback_phone):
            tx.status = "FAILED"; tx.metadata = {**body, "validation_error": "M-Pesa callback did not match transaction amount or payer phone."}
            tx.save(update_fields=["status", "metadata"])
            logger.warning("Rejected M-Pesa callback validation mismatch for %s", tx.reference)
            return JsonResponse({"ResultCode": 0, "ResultDesc": "Accepted"})
        tx.status = "PAID"; tx.paid_at = timezone.now(); tx.metadata = body
        tx.save(update_fields=["status", "paid_at", "metadata"])
        if tx.order:
            tx.order.status = "PAID"; tx.order.save(update_fields=["status"])
        if tx.job:
            tx.job.status = "IN_PROGRESS"; tx.job.save(update_fields=["status"])
    return JsonResponse({"ResultCode": 0, "ResultDesc": "Accepted"})

@login_required
def manager_dashboard(request):
    if request.user.role!="MANAGER" and not request.user.is_superuser: return HttpResponseForbidden()
    return render(request,"marketplace/manager.html",{"pending_riders":RiderProfile.objects.filter(status="PENDING").select_related("user"),"pending_companies":CompanyProfile.objects.filter(status="PENDING").select_related("user")})

@login_required
def approve_rider(request,pk):
    if request.user.role!="MANAGER" and not request.user.is_superuser: return HttpResponseForbidden()
    rider=get_object_or_404(RiderProfile,pk=pk)
    if request.method=="POST":
        rider.status="APPROVED"; rider.approved_at=timezone.now(); rider.approved_by=request.user; rider.save(update_fields=["status","approved_at","approved_by"])
        rider.user.is_identity_verified=True; rider.user.save(update_fields=["is_identity_verified"]); messages.success(request,"Rider approved.")
    return redirect("manager_dashboard")

@login_required
def reject_rider(request,pk):
    if request.user.role!="MANAGER" and not request.user.is_superuser: return HttpResponseForbidden()
    rider=get_object_or_404(RiderProfile,pk=pk)
    if request.method=="POST": rider.status="REJECTED"; rider.save(update_fields=["status"]); messages.success(request,"Rider rejected.")
    return redirect("manager_dashboard")

@login_required
def approve_company(request,pk):
    if request.user.role!="MANAGER" and not request.user.is_superuser: return HttpResponseForbidden()
    company=get_object_or_404(CompanyProfile,pk=pk)
    if request.method=="POST": company.status="APPROVED"; company.approved_at=timezone.now(); company.approved_by=request.user; company.save(update_fields=["status","approved_at","approved_by"]); messages.success(request,"Company approved.")
    return redirect("manager_dashboard")

@csrf_exempt
def mpesa_b2c_result(request):
    if request.method != "POST": return JsonResponse({"ResultCode":1,"ResultDesc":"POST required"},status=405)
    try: body=json.loads(request.body.decode("utf-8"))
    except Exception: return JsonResponse({"ResultCode":1,"ResultDesc":"Invalid JSON"},status=400)
    result=body.get("Result",{}); ref=result.get("OriginatorConversationID",""); code=result.get("ResultCode")
    tx=Transaction.objects.filter(payout_reference=ref,payout_status="PENDING").first()
    if tx:
        tx.metadata={**(tx.metadata or {}),"payout_result":body}
        if code==0: tx.payout_status="PAID"; tx.status="RELEASED"; tx.released_at=timezone.now()
        else: tx.payout_status="FAILED"
        tx.save(update_fields=["metadata","payout_status","status","released_at"] if code==0 else ["metadata","payout_status"])
    return JsonResponse({"ResultCode":0,"ResultDesc":"Accepted"})

@csrf_exempt
def mpesa_b2c_timeout(request):
    return JsonResponse({"ResultCode":0,"ResultDesc":"Accepted"})

@login_required
def company_order_status(request,pk):
    company=get_object_or_404(CompanyProfile,user=request.user)
    order=get_object_or_404(Order,pk=pk,company=company)
    allowed={"PAID":"ACCEPTED","ACCEPTED":"PREPARING","PREPARING":"READY"}
    if request.method=="POST" and order.status in allowed: order.status=allowed[order.status]; order.save(update_fields=["status"]); messages.success(request,f"Order #{order.id} is now {order.status.lower()}.")
    return redirect("dashboard")


@login_required
def tracking_page(request, pk):
    order = get_object_or_404(Order.objects.select_related("customer", "company"), pk=pk)
    delivery = getattr(order, "delivery", None)
    if request.user.id != order.customer_id and (delivery is None or request.user.id != delivery.rider_id): return HttpResponseForbidden()
    return render(request, "marketplace/tracking.html", {"order": order, "delivery": delivery})

@login_required
def tracking_data(request, pk):
    order = get_object_or_404(Order.objects.select_related("customer"), pk=pk)
    delivery = getattr(order, "delivery", None)
    if request.user.id != order.customer_id and (delivery is None or request.user.id != delivery.rider_id):
        return HttpResponseForbidden()
    data = {"order_status": order.status, "destination": {"lat": str(order.delivery_lat) if order.delivery_lat is not None else None, "lng": str(order.delivery_lng) if order.delivery_lng is not None else None}}
    if delivery:
        data["rider"] = {"name": delivery.rider.get_full_name() or delivery.rider.username, "phone": delivery.rider.phone, "lat": str(delivery.current_lat) if delivery.current_lat is not None else None, "lng": str(delivery.current_lng) if delivery.current_lng is not None else None, "updated_at": delivery.location_updated_at.isoformat() if delivery.location_updated_at else None, "status": delivery.status}
        # Customer contact and exact delivery point are revealed only after a rider accepts.
        data["customer"] = {"phone": order.delivery_phone, "address": order.delivery_address, "lat": data["destination"]["lat"], "lng": data["destination"]["lng"]}
    return JsonResponse(data)

# V2.2 commercial workflow overrides: customer acceptance closes GPS tracking and enables verified ratings.
@login_required
def update_delivery(request, pk):
    if request.method != "POST" or request.user.role != "RIDER":
        return HttpResponseForbidden()
    delivery = get_object_or_404(Delivery.objects.select_related("order"), pk=pk, rider=request.user)
    if not getattr(request.user, "rider_profile", None) or not request.user.rider_profile.is_approved:
        return HttpResponseForbidden()
    allowed = {"ASSIGNED": "PICKED_UP", "PICKED_UP": "IN_TRANSIT", "IN_TRANSIT": "DELIVERED"}
    next_status = allowed.get(delivery.status)
    if request.method == "POST" and request.POST.get("status") == next_status:
        delivery.status = next_status
        delivery.save(update_fields=["status", "updated_at"])
        if next_status == "DELIVERED":
            delivery.order.status = "DELIVERED"
            delivery.order.save(update_fields=["status"])
            # Do NOT release funds yet. Customer must confirm receipt.
        messages.success(request, "Delivery status updated. Customer confirmation is required before completion and payout.")
    return redirect("dashboard")

@login_required
def confirm_delivery_received(request, pk):
    if request.method != "POST":
        return HttpResponseForbidden()
    with db_transaction.atomic():
        order = get_object_or_404(Order.objects.select_for_update().select_related("delivery"), pk=pk, customer=request.user, status="DELIVERED")
        delivery = get_object_or_404(Delivery.objects.select_for_update(), order=order, status="DELIVERED")
        order.status = "RECEIVED"
        order.save(update_fields=["status"])
        # Clearing coordinates makes the live location endpoint stop exposing the rider location.
        delivery.status = "DELIVERED"
        delivery.current_lat = None
        delivery.current_lng = None
        delivery.location_updated_at = None
        delivery.completed_at = timezone.now()
        delivery.save(update_fields=["current_lat", "current_lng", "location_updated_at", "completed_at", "updated_at"])
        if delivery.rider_id:
            RiderProfile.objects.filter(user_id=delivery.rider_id).update(current_lat=None, current_lng=None, location_updated_at=None)
        tx = getattr(order, "transaction", None)
        if tx:
            _request_payout(tx)
    messages.success(request, "Delivery received. Live rider tracking has ended. You can now rate the rider and company.")
    return redirect("order_tracking", pk=pk)

@login_required
def rate_order(request, pk):
    order = get_object_or_404(Order.objects.select_related("company", "delivery", "delivery__rider"), pk=pk, customer=request.user, status="RECEIVED")
    if request.method != "POST":
        return redirect("order_tracking", pk=pk)
    kind = request.POST.get("kind")
    targets = {"ORDER_RIDER": getattr(order.delivery, "rider", None), "ORDER_COMPANY": order.company.user}
    target = targets.get(kind)
    if not target or target.id == request.user.id:
        return HttpResponseForbidden()
    if Rating.objects.filter(rater=request.user, order=order, kind=kind).exists():
        messages.info(request, "You have already rated this transaction.")
        return redirect("order_tracking", pk=pk)
    form = RatingForm(request.POST)
    if form.is_valid() and kind in {"ORDER_RIDER", "ORDER_COMPANY"}:
        rating = form.save(commit=False)
        rating.rater = request.user; rating.rated = target; rating.order = order; rating.kind = kind; rating.save()
        messages.success(request, "Thank you. Your rating has been recorded.")
    else:
        messages.error(request, "Please provide a rating from 1 to 5.")
    return redirect("order_tracking", pk=pk)

@login_required
def rate_job(request, pk):
    job = get_object_or_404(Job.objects.select_related("poster", "assigned_to"), pk=pk, status="COMPLETED")
    if request.user.id not in {job.poster_id, job.assigned_to_id}:
        return HttpResponseForbidden()
    kind = request.POST.get("kind")
    if kind == "JOB_WORKER" and request.user.id == job.poster_id:
        target = job.assigned_to
    elif kind == "JOB_POSTER" and request.user.id == job.assigned_to_id:
        target = job.poster
    else:
        return HttpResponseForbidden()
    if Rating.objects.filter(rater=request.user, job=job, kind=kind).exists():
        messages.info(request, "You have already rated this completed job.")
        return redirect("job_detail", pk=pk)
    form = RatingForm(request.POST)
    if form.is_valid():
        rating = form.save(commit=False); rating.rater=request.user; rating.rated=target; rating.job=job; rating.kind=kind; rating.save()
        messages.success(request, "Your job rating has been recorded.")
    else:
        messages.error(request, "Please provide a rating from 1 to 5.")
    return redirect("job_detail", pk=pk)

# Override tracking payload so a completed/received delivery never leaks a final GPS coordinate.
@login_required
def order_tracking_data(request, pk):
    order = get_object_or_404(Order.objects.select_related("customer", "delivery", "delivery__rider"), pk=pk, customer=request.user)
    delivery = getattr(order, "delivery", None)
    if delivery is None:
        return JsonResponse({"assigned": False, "message": "A driver has not accepted this order yet."})
    active = delivery.status in {"ASSIGNED", "PICKED_UP", "IN_TRANSIT"} and order.status != "RECEIVED"
    data = {"assigned": True, "active_tracking": active, "delivery_status": delivery.status, "order_status": order.status}
    if not active:
        data["message"] = "Delivery completed. Live rider tracking has ended."
        return JsonResponse(data)
    rider = delivery.rider
    data.update({
        "rider_name": rider.get_full_name() or rider.username,
        "rider_phone": rider.phone,
        "rider_lat": str(delivery.current_lat) if delivery.current_lat is not None else None,
        "rider_lng": str(delivery.current_lng) if delivery.current_lng is not None else None,
        "location_updated_at": delivery.location_updated_at.isoformat() if delivery.location_updated_at else None,
        "delivery_address": order.delivery_address,
        "customer_phone": order.delivery_phone or order.customer.phone,
        "destination_lat": str(order.delivery_lat) if order.delivery_lat is not None else None,
        "destination_lng": str(order.delivery_lng) if order.delivery_lng is not None else None,
    })
    return JsonResponse(data)

@login_required
def order_tracking(request, pk):
    order = get_object_or_404(Order.objects.select_related("company", "delivery", "delivery__rider"), pk=pk, customer=request.user)
    delivery = getattr(order, "delivery", None)
    return render(request, "marketplace/order_tracking.html", {
        "order": order,
        "delivery": delivery,
        "rider_rated": bool(delivery and Rating.objects.filter(rater=request.user, order=order, kind="ORDER_RIDER").exists()),
        "company_rated": Rating.objects.filter(rater=request.user, order=order, kind="ORDER_COMPANY").exists(),
    })

@login_required
def job_detail(request, pk):
    job = get_object_or_404(Job.objects.select_related("poster", "assigned_to"), pk=pk)
    return render(request, "marketplace/job_detail.html", {
        "job": job,
        "bids": job.bids.select_related("bidder").order_by("-created_at"),
        "worker_rated": Rating.objects.filter(rater=request.user, job=job, kind="JOB_WORKER").exists(),
        "poster_rated": Rating.objects.filter(rater=request.user, job=job, kind="JOB_POSTER").exists(),
    })


def _distance_km(lat1, lon1, lat2, lon2):
    r = 6371.0088
    p1, p2 = math.radians(float(lat1)), math.radians(float(lat2))
    dp = math.radians(float(lat2) - float(lat1)); dl = math.radians(float(lon2) - float(lon1))
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return r * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

@login_required
def update_rider_location(request, pk):
    if request.method != "POST" or request.user.role != "RIDER": return HttpResponseForbidden()
    delivery = get_object_or_404(Delivery, pk=pk, rider=request.user)
    if not request.user.rider_profile.is_approved or delivery.status not in {"ASSIGNED", "PICKED_UP", "IN_TRANSIT"}: return HttpResponseForbidden()
    try:
        payload=json.loads(request.body.decode("utf-8")); lat=_valid_coordinate(payload.get("lat"),-90,90); lng=_valid_coordinate(payload.get("lng"),-180,180)
        if lat is None or lng is None: raise ValueError
    except (ValueError,TypeError,json.JSONDecodeError): return JsonResponse({"error":"Valid latitude and longitude are required."},status=400)
    now=timezone.now(); delivery.current_lat=lat; delivery.current_lng=lng; delivery.location_updated_at=now; delivery.save(update_fields=["current_lat","current_lng","location_updated_at","updated_at"])
    profile=request.user.rider_profile; profile.current_lat=lat; profile.current_lng=lng; profile.location_updated_at=now; profile.save(update_fields=["current_lat","current_lng","location_updated_at"])
    return JsonResponse({"ok":True,"updated_at":now.isoformat()})

# V2.3 payment + notification overrides
from .notifications import notify

logger = logging.getLogger(__name__)

@login_required
def take_delivery(request, pk):
    if request.method != "POST" or request.user.role != "RIDER" or not getattr(request.user, "rider_profile", None) or not request.user.rider_profile.is_approved:
        return HttpResponseForbidden("Approved riders only.")
    order = get_object_or_404(Order.objects.select_related("company", "customer"), pk=pk, status="READY", delivery__isnull=True)
    lat = _valid_coordinate(request.POST.get("lat"), -90, 90); lng = _valid_coordinate(request.POST.get("lng"), -180, 180)
    if lat is None or lng is None:
        messages.error(request, "GPS permission is required to take a delivery."); return redirect("dashboard")
    if order.delivery_lat is not None and order.delivery_lng is not None:
        distance = _distance_km(lat, lng, order.delivery_lat, order.delivery_lng)
        if distance > float(settings.RIDER_MAX_DELIVERY_DISTANCE_KM):
            messages.error(request, f"You are about {distance:.1f} km from the delivery point. Move closer before accepting this order."); return redirect("dashboard")
    with db_transaction.atomic():
        order = get_object_or_404(Order.objects.select_for_update(), pk=pk, status="READY", delivery__isnull=True)
        now = timezone.now()
        Delivery.objects.create(order=order, rider=request.user, status="ASSIGNED", current_lat=lat, current_lng=lng, location_updated_at=now)
        order.status = "PICKED_UP"; order.save(update_fields=["status"])
        profile = request.user.rider_profile; profile.current_lat=lat; profile.current_lng=lng; profile.location_updated_at=now; profile.save(update_fields=["current_lat","current_lng","location_updated_at"])
    notify(order.customer, "Your order has been picked up", f"Order #{order.id} from {order.company.business_name} has been picked up by a delivery rider. You can now track the rider live from your account.", metadata={"order_id":order.id,"event":"ORDER_PICKED_UP"})
    messages.success(request, "Delivery assigned. The customer has been notified and live tracking is active.")
    return redirect("dashboard")

@login_required
def payment_checkout(request, transaction_ref):
    tx = get_object_or_404(Transaction, reference=transaction_ref, payer=request.user)
    if tx.status != "PENDING": return redirect("dashboard")
    if request.method == "POST":
        provider = request.POST.get("provider", "MPESA").upper()
        from .payments import PayPalGateway
        if provider == "PAYPAL":
            if settings.PAYPAL_CURRENCY != "KES":
                messages.error(request, "PayPal checkout is not enabled for KES in this build. Use M-Pesa, or configure a supported PayPal currency conversion flow before enabling PayPal.")
                return redirect("payments_checkout", transaction_ref=tx.reference)
            try:
                result = PayPalGateway().create_order(tx.gross_amount, tx.reference)
                tx.provider="PAYPAL"; tx.paypal_order_id=result.get("id", ""); tx.provider_reference=result.get("id", ""); tx.metadata=result; tx.save(update_fields=["provider","paypal_order_id","provider_reference","metadata"])
                approval = next((x.get("href") for x in result.get("links",[]) if x.get("rel") == "approve"), None)
                if not approval: raise RuntimeError("PayPal did not return an approval URL.")
                return redirect(approval)
            except Exception as exc:
                logger.exception("PayPal order creation failed for %s", tx.reference); messages.error(request, "PayPal could not start the payment. Please try again or choose M-Pesa.")
        else:
            phone=request.POST.get("phone") or request.user.phone
            if tx.gross_amount != tx.gross_amount.to_integral_value():
                messages.error(request, "M-Pesa payments must be for a whole KES amount. Please ask the seller to use a whole-shilling price or choose PayPal.")
                return render(request,"marketplace/payment.html",{"tx":tx,"fee_percent":((tx.platform_fee/tx.gross_amount)*Decimal("100")) if tx.gross_amount else Decimal("0"),"demo_enabled":False,"paypal_enabled":PayPalGateway().enabled()})
            from .payments import MpesaGateway
            try:
                response=MpesaGateway().stk_push(phone,tx.gross_amount,tx.reference)
                tx.provider="MPESA"; tx.provider_reference=response.get("CheckoutRequestID",""); tx.metadata=response; tx.save(update_fields=["provider","provider_reference","metadata"])
                messages.success(request,"M-Pesa prompt sent. Complete the PIN request; payment will be confirmed automatically.")
                return redirect("dashboard")
            except Exception:
                logger.exception("M-Pesa payment initiation failed for %s", tx.reference); messages.error(request,"M-Pesa payment could not be started. Please check the number and try again.")
    from .payments import PayPalGateway
    return render(request,"marketplace/payment.html",{"tx":tx,"fee_percent":((tx.platform_fee/tx.gross_amount)*Decimal("100")) if tx.gross_amount else Decimal("0"),"demo_enabled":False,"paypal_enabled":PayPalGateway().enabled()})

@login_required
def paypal_return(request):
    order_id=request.GET.get("token")
    if not order_id: messages.error(request,"PayPal payment reference is missing."); return redirect("dashboard")
    tx=get_object_or_404(Transaction, paypal_order_id=order_id, payer=request.user, status="PENDING")
    from .payments import PayPalGateway
    try:
        result=PayPalGateway().capture_order(order_id)
        status=result.get("status")
        capture=None
        for pu in result.get("purchase_units",[]):
            for p in pu.get("payments",{}).get("captures",[]):
                capture=p; break
        if status != "COMPLETED" or not capture or capture.get("status") != "COMPLETED":
            raise RuntimeError("PayPal did not confirm the payment.")
        amount=capture.get("amount",{}).get("value"); currency=capture.get("amount",{}).get("currency_code")
        if currency != settings.PAYPAL_CURRENCY or Decimal(str(amount)) != tx.gross_amount:
            raise RuntimeError("The captured PayPal amount does not match the transaction.")
        tx.status="PAID"; tx.paid_at=timezone.now(); tx.provider_reference=capture.get("id",order_id); tx.metadata=result; tx.save(update_fields=["status","paid_at","provider_reference","metadata"])
        if tx.order: tx.order.status="PAID"; tx.order.save(update_fields=["status"])
        if tx.job: tx.job.status="IN_PROGRESS"; tx.job.save(update_fields=["status"])
        messages.success(request,"PayPal payment confirmed successfully.")
    except Exception:
        logger.exception("PayPal capture failed for %s", tx.reference); messages.error(request,"PayPal payment could not be confirmed. Please contact support if your PayPal account was charged.")
    return redirect("dashboard")

@login_required
def paypal_cancel(request):
    messages.info(request,"PayPal payment was cancelled. Your transaction remains unpaid.")
    return redirect("dashboard")

@csrf_exempt
def paypal_webhook(request):
    if request.method != "POST":
        return JsonResponse({"error":"POST required"}, status=405)
    try:
        event = json.loads(request.body.decode("utf-8"))
    except Exception:
        return JsonResponse({"error":"Invalid JSON"}, status=400)
    from .payments import PayPalGateway
    try:
        if not PayPalGateway().verify_webhook(request.headers, event):
            return JsonResponse({"error":"Invalid PayPal signature"}, status=400)
    except Exception:
        logger.exception("PayPal webhook verification failed")
        return JsonResponse({"error":"Webhook verification failed"}, status=400)
    # Only a completed capture can settle money. CHECKOUT.ORDER.COMPLETED is intentionally
    # ignored because it does not itself prove that the expected amount was captured.
    if event.get("event_type") != "PAYMENT.CAPTURE.COMPLETED":
        return JsonResponse({"received":True})
    resource = event.get("resource", {})
    order_id = resource.get("supplementary_data", {}).get("related_ids", {}).get("order_id")
    if not order_id:
        return JsonResponse({"error":"Missing PayPal order reference"}, status=400)
    tx = Transaction.objects.filter(paypal_order_id=order_id, provider="PAYPAL").first()
    if not tx:
        return JsonResponse({"received":True})
    amount = resource.get("amount", {}).get("value")
    currency = resource.get("amount", {}).get("currency_code")
    try:
        amount = Decimal(str(amount))
    except (TypeError, ValueError, ArithmeticError):
        return JsonResponse({"error":"Invalid capture amount"}, status=400)
    if currency != settings.PAYPAL_CURRENCY or amount != tx.gross_amount:
        logger.warning("Rejected PayPal amount mismatch for %s", tx.reference)
        return JsonResponse({"error":"Capture amount mismatch"}, status=400)
    with db_transaction.atomic():
        tx = Transaction.objects.select_for_update().get(pk=tx.pk)
        if tx.status == "PENDING":
            tx.status="PAID"; tx.paid_at=timezone.now(); tx.provider_reference=resource.get("id",tx.provider_reference); tx.metadata={**(tx.metadata or {}),"webhook":event}; tx.save(update_fields=["status","paid_at","provider_reference","metadata"])
            if tx.order:
                tx.order.status="PAID"; tx.order.save(update_fields=["status"])
            if tx.job:
                tx.job.status="IN_PROGRESS"; tx.job.save(update_fields=["status"])
    return JsonResponse({"received":True})
