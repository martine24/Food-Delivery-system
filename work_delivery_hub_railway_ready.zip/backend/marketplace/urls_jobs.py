from django.urls import path
from . import views
urlpatterns=[path("",views.job_list,name="job_list"),path("post/",views.create_job,name="create_job"),path("<int:pk>/",views.job_detail,name="job_detail"),path("<int:pk>/bid/",views.bid_job,name="bid_job"),path("<int:pk>/accept/",views.accept_bid,name="accept_bid"),path("<int:pk>/submit/",views.submit_job,name="submit_job"),path("<int:pk>/approve/",views.approve_submission,name="approve_submission"),path("<int:pk>/rate/",views.rate_job,name="rate_job")]
