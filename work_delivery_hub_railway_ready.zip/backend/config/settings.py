import os
from decimal import Decimal
from pathlib import Path
from urllib.parse import urlparse, unquote
BASE_DIR=Path(__file__).resolve().parent.parent

def env_bool(name,default=False): return os.getenv(name,str(default)).lower() in {"1","true","yes","on"}
def env_list(name,default=""): return [x.strip() for x in os.getenv(name,default).split(",") if x.strip()]
SECRET_KEY=os.getenv("DJANGO_SECRET_KEY", "")
DEBUG=env_bool("DJANGO_DEBUG", False)
ALLOWED_HOSTS=env_list("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1")
# Railway health checks use this hostname; Railway also exposes the public domain at runtime.
for _host in ["healthcheck.railway.app", os.getenv("RAILWAY_PUBLIC_DOMAIN", "")]:
    if _host and _host not in ALLOWED_HOSTS:
        ALLOWED_HOSTS.append(_host)
if not DEBUG and (not SECRET_KEY or SECRET_KEY == "dev-only-change-me"):
    raise RuntimeError("DJANGO_SECRET_KEY must be set to a strong unique value when DJANGO_DEBUG=False.")
if not DEBUG and not ALLOWED_HOSTS:
    raise RuntimeError("DJANGO_ALLOWED_HOSTS must contain the production hostname(s).")
DATABASE_URL=os.getenv("DATABASE_URL")
if not DEBUG and (not DATABASE_URL or not DATABASE_URL.startswith(("postgres://", "postgresql://"))):
    raise RuntimeError("Production requires a PostgreSQL DATABASE_URL.")
CSRF_TRUSTED_ORIGINS=env_list("CSRF_TRUSTED_ORIGINS")
INSTALLED_APPS=["django.contrib.admin","django.contrib.auth","django.contrib.contenttypes","django.contrib.sessions","django.contrib.messages","django.contrib.staticfiles","marketplace"]
MIDDLEWARE=["django.middleware.security.SecurityMiddleware","whitenoise.middleware.WhiteNoiseMiddleware","django.contrib.sessions.middleware.SessionMiddleware","django.middleware.common.CommonMiddleware","django.middleware.csrf.CsrfViewMiddleware","django.contrib.auth.middleware.AuthenticationMiddleware","django.contrib.messages.middleware.MessageMiddleware","django.middleware.clickjacking.XFrameOptionsMiddleware"]
ROOT_URLCONF="config.urls"; WSGI_APPLICATION="config.wsgi.application"; ASGI_APPLICATION="config.asgi.application"
TEMPLATES=[{"BACKEND":"django.template.backends.django.DjangoTemplates","DIRS":[BASE_DIR/"templates"],"APP_DIRS":True,"OPTIONS":{"context_processors":["django.template.context_processors.request","django.contrib.auth.context_processors.auth","django.contrib.messages.context_processors.messages"]}}]
if DATABASE_URL:
    u=urlparse(DATABASE_URL); DATABASES={"default":{"ENGINE":"django.db.backends.postgresql","NAME":unquote(u.path.lstrip("/")),"USER":unquote(u.username or ""),"PASSWORD":unquote(u.password or ""),"HOST":u.hostname,"PORT":u.port or 5432,"CONN_MAX_AGE":60}}
else: DATABASES={"default":{"ENGINE":"django.db.backends.sqlite3","NAME":BASE_DIR/"db.sqlite3"}}
AUTH_USER_MODEL="marketplace.User"
AUTH_PASSWORD_VALIDATORS=[{"NAME":"django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},{"NAME":"django.contrib.auth.password_validation.MinimumLengthValidator"},{"NAME":"django.contrib.auth.password_validation.CommonPasswordValidator"}]
LANGUAGE_CODE="en-us"; TIME_ZONE=os.getenv("TIME_ZONE","Africa/Nairobi"); USE_I18N=True; USE_TZ=True
STATIC_URL="/static/"; STATIC_ROOT=BASE_DIR/"staticfiles"; STATICFILES_DIRS=[BASE_DIR/"static"]
MEDIA_URL="/media/"; MEDIA_ROOT=BASE_DIR/"media"
STORAGES={"default":{"BACKEND":"django.core.files.storage.FileSystemStorage"},"staticfiles":{"BACKEND":"whitenoise.storage.CompressedManifestStaticFilesStorage"}}
DEFAULT_AUTO_FIELD="django.db.models.BigAutoField"; LOGIN_URL="/accounts/login/"; LOGIN_REDIRECT_URL="/dashboard/"; LOGOUT_REDIRECT_URL="/"
PLATFORM_FEE_PERCENT=int(os.getenv("PLATFORM_FEE_PERCENT","5"))
RIDER_MAX_DELIVERY_DISTANCE_KM=Decimal(os.getenv("RIDER_MAX_DELIVERY_DISTANCE_KM","10"))
MPESA_ENVIRONMENT=os.getenv("MPESA_ENVIRONMENT","sandbox"); MPESA_CONSUMER_KEY=os.getenv("MPESA_CONSUMER_KEY",""); MPESA_CONSUMER_SECRET=os.getenv("MPESA_CONSUMER_SECRET",""); MPESA_SHORTCODE=os.getenv("MPESA_SHORTCODE",""); MPESA_PASSKEY=os.getenv("MPESA_PASSKEY",""); MPESA_CALLBACK_URL=os.getenv("MPESA_CALLBACK_URL",""); MPESA_INITIATOR_NAME=os.getenv("MPESA_INITIATOR_NAME",""); MPESA_SECURITY_CREDENTIAL=os.getenv("MPESA_SECURITY_CREDENTIAL",""); MPESA_QUEUE_TIMEOUT_URL=os.getenv("MPESA_QUEUE_TIMEOUT_URL",""); MPESA_RESULT_URL=os.getenv("MPESA_RESULT_URL","")
EMAIL_BACKEND="django.core.mail.backends.smtp.EmailBackend" if os.getenv("EMAIL_HOST") else "django.core.mail.backends.console.EmailBackend"
EMAIL_HOST=os.getenv("EMAIL_HOST",""); EMAIL_PORT=int(os.getenv("EMAIL_PORT","587")); EMAIL_HOST_USER=os.getenv("EMAIL_HOST_USER",""); EMAIL_HOST_PASSWORD=os.getenv("EMAIL_HOST_PASSWORD",""); EMAIL_USE_TLS=env_bool("EMAIL_USE_TLS",True); DEFAULT_FROM_EMAIL=os.getenv("DEFAULT_FROM_EMAIL","no-reply@example.com")
DATA_UPLOAD_MAX_MEMORY_SIZE=10*1024*1024; FILE_UPLOAD_MAX_MEMORY_SIZE=5*1024*1024
if not DEBUG:
    SECURE_SSL_REDIRECT=env_bool("SECURE_SSL_REDIRECT",True); SECURE_PROXY_SSL_HEADER=("HTTP_X_FORWARDED_PROTO","https"); SESSION_COOKIE_SECURE=True; CSRF_COOKIE_SECURE=True
    SECURE_HSTS_SECONDS=31536000; SECURE_HSTS_INCLUDE_SUBDOMAINS=True; SECURE_HSTS_PRELOAD=True
    SECURE_CONTENT_TYPE_NOSNIFF=True; X_FRAME_OPTIONS="DENY"; SECURE_REFERRER_POLICY="strict-origin-when-cross-origin"
    SESSION_COOKIE_HTTPONLY=True; SESSION_COOKIE_SAMESITE="Lax"; CSRF_COOKIE_SAMESITE="Lax"

# PayPal Checkout (server-side Orders v2 + verified webhooks)
PAYPAL_ENABLED=env_bool("PAYPAL_ENABLED",False)
PAYPAL_ENVIRONMENT=os.getenv("PAYPAL_ENVIRONMENT","sandbox")
PAYPAL_CLIENT_ID=os.getenv("PAYPAL_CLIENT_ID","")
PAYPAL_CLIENT_SECRET=os.getenv("PAYPAL_CLIENT_SECRET","")
PAYPAL_CURRENCY=os.getenv("PAYPAL_CURRENCY","KES")
PAYPAL_RETURN_URL=os.getenv("PAYPAL_RETURN_URL","")
PAYPAL_CANCEL_URL=os.getenv("PAYPAL_CANCEL_URL","")
PAYPAL_WEBHOOK_ID=os.getenv("PAYPAL_WEBHOOK_ID","")

# Africa's Talking transactional SMS
AT_ENABLED=env_bool("AT_ENABLED",False)
AT_USERNAME=os.getenv("AT_USERNAME","")
AT_API_KEY=os.getenv("AT_API_KEY","")
AT_SENDER_ID=os.getenv("AT_SENDER_ID","")
AT_SMS_URL=os.getenv("AT_SMS_URL","https://api.africastalking.com/version1/messaging")

if not DEBUG:
    if not CSRF_TRUSTED_ORIGINS:
        # Same-origin POSTs work without this, but explicit HTTPS origins are strongly recommended.
        pass
    if MPESA_ENVIRONMENT == "production":
        required_mpesa = [MPESA_CONSUMER_KEY, MPESA_CONSUMER_SECRET, MPESA_SHORTCODE, MPESA_PASSKEY, MPESA_CALLBACK_URL]
        if not all(required_mpesa):
            raise RuntimeError("Production M-Pesa is incomplete: configure consumer credentials, shortcode, passkey and HTTPS callback URL.")
        if not MPESA_CALLBACK_URL.startswith("https://"):
            raise RuntimeError("MPESA_CALLBACK_URL must use HTTPS in production.")
        required_b2c = [MPESA_INITIATOR_NAME, MPESA_SECURITY_CREDENTIAL, MPESA_QUEUE_TIMEOUT_URL, MPESA_RESULT_URL]
        if not all(required_b2c):
            raise RuntimeError("Production M-Pesa payouts are incomplete: configure B2C initiator, security credential and HTTPS callback URLs.")
        if not MPESA_QUEUE_TIMEOUT_URL.startswith("https://") or not MPESA_RESULT_URL.startswith("https://"):
            raise RuntimeError("M-Pesa B2C callback URLs must use HTTPS in production.")
    if PAYPAL_ENABLED and PAYPAL_ENVIRONMENT == "production":
        if not all([PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_RETURN_URL, PAYPAL_CANCEL_URL, PAYPAL_WEBHOOK_ID]):
            raise RuntimeError("Production PayPal is incomplete: configure live credentials, return/cancel URLs and webhook ID.")
        if PAYPAL_CURRENCY == "KES":
            raise RuntimeError("PayPal production cannot be configured as KES: current PayPal REST checkout currency support does not list KES. Use a supported presentment currency with a verified KES conversion flow.")
        if not PAYPAL_RETURN_URL.startswith("https://") or not PAYPAL_CANCEL_URL.startswith("https://"):
            raise RuntimeError("PayPal production return/cancel URLs must use HTTPS.")

# Production diagnostics. Payment/provider secrets are never logged.
LOGGING={"version":1,"disable_existing_loggers":False,"handlers":{"console":{"class":"logging.StreamHandler"}},"loggers":{"django":{"handlers":["console"],"level":"WARNING"},"marketplace":{"handlers":["console"],"level":"INFO","propagate":False}}}
