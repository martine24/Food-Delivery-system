from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path, include
from django.views.decorators.http import require_GET
from django.http import JsonResponse
from django.db import connection
from marketplace import views
from marketplace.legal import PrivacyPolicyView, TermsView, RefundPolicyView
from marketplace import api

@require_GET
def health(request):
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
        return JsonResponse({"status":"ok","database":"ok"})
    except Exception:
        return JsonResponse({"status":"error","database":"unavailable"}, status=503)
urlpatterns=[path("api/v1/auth/login/",api.login_api,name="api_login"),path("api/v1/auth/register/",api.register_api,name="api_register"),path("api/v1/auth/logout/",api.logout_api,name="api_logout"),path("api/v1/me/",api.me,name="api_me"),path("api/v1/companies/",api.companies,name="api_companies"),path("api/v1/orders/",api.orders_api,name="api_orders"),path("api/v1/jobs/",api.jobs_api,name="api_jobs"),path("api/v1/jobs/<int:pk>/bid/",api.bid_api,name="api_bid"),path("api/v1/rider/orders/",api.rider_orders,name="api_rider_orders"),path("api/v1/rider/orders/<int:pk>/accept/",api.accept_delivery,name="api_accept"),path("api/v1/rider/location/",api.rider_location,name="api_rider_location"),path("api/v1/orders/<int:pk>/tracking/",api.tracking_api,name="api_tracking"),path("api/v1/orders/<int:pk>/receive/",api.receive_order,name="api_receive"),path("api/v1/orders/<int:pk>/rating/",api.rate_order_api,name="api_rate_order"),path("api/v1/payments/mpesa/",api.mpesa_api,name="api_mpesa"),path("api/v1/payments/<str:reference>/",api.payment_status_api,name="api_payment_status"),path("api/v1/company/orders/",api.company_orders_api,name="api_company_orders"),path("api/v1/notifications/",api.notifications_api,name="api_notifications"),path("privacy/",PrivacyPolicyView.as_view(),name="privacy"),path("terms/",TermsView.as_view(),name="terms"),path("refunds/",RefundPolicyView.as_view(),name="refunds"),path("admin/",admin.site.urls),path("health/",health,name="health"),path("files/<str:kind>/<int:pk>/",views.protected_file,name="protected_file"),path("",views.home,name="home"),path("register/",views.register,name="register"),path("accounts/login/",auth_views.LoginView.as_view(template_name="registration/login.html"),name="login"),path("accounts/logout/",auth_views.LogoutView.as_view(),name="logout"),path("accounts/password-reset/",auth_views.PasswordResetView.as_view(template_name="registration/password_reset_form.html",email_template_name="registration/password_reset_email.html",subject_template_name="registration/password_reset_subject.txt"),name="password_reset"),path("accounts/password-reset/done/",auth_views.PasswordResetDoneView.as_view(template_name="registration/password_reset_done.html"),name="password_reset_done"),path("accounts/reset/<uidb64>/<token>/",auth_views.PasswordResetConfirmView.as_view(template_name="registration/password_reset_confirm.html"),name="password_reset_confirm"),path("accounts/reset/done/",auth_views.PasswordResetCompleteView.as_view(template_name="registration/password_reset_complete.html"),name="password_reset_complete"),path("dashboard/",views.dashboard,name="dashboard"),path("companies/",include("marketplace.urls_company")),path("jobs/",include("marketplace.urls_jobs")),path("orders/",include("marketplace.urls_orders")),path("riders/",include("marketplace.urls_riders")),path("manager/",views.manager_dashboard,name="manager_dashboard"),path("manager/riders/<int:pk>/approve/",views.approve_rider,name="approve_rider"),path("manager/riders/<int:pk>/reject/",views.reject_rider,name="reject_rider"),path("manager/companies/<int:pk>/approve/",views.approve_company,name="approve_company"),path("payments/",include("marketplace.urls_payments")),path("payments/mpesa/b2c/result/",views.mpesa_b2c_result,name="mpesa_b2c_result"),path("payments/mpesa/b2c/timeout/",views.mpesa_b2c_timeout,name="mpesa_b2c_timeout")]
if settings.DEBUG: urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
urlpatterns += [path("payments/paypal/return/", views.paypal_return, name="paypal_return"), path("payments/paypal/cancel/", views.paypal_cancel, name="paypal_cancel"), path("payments/paypal/webhook/", views.paypal_webhook, name="paypal_webhook")]
