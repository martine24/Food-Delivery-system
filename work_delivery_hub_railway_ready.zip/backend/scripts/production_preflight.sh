#!/usr/bin/env bash
set -euo pipefail

python manage.py check --deploy
python manage.py makemigrations --check --dry-run
python manage.py migrate --check
python manage.py collectstatic --noinput
python manage.py test

echo "Production preflight completed. Provider credentials and live callback tests must still be completed against sandbox/live services."
