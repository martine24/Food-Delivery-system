# Work & Delivery Hub — Production Audit

## Scope
This release contains the connected Django backend and native Kotlin/Jetpack Compose Android client.

## Corrected in this audit
- Native Android UI source is the current UI-complete version; the previous combined ZIP's older Android UI is no longer used.
- Token API authentication is hash-backed, expires after 30 days, and supports explicit logout/revocation.
- Token-authenticated API routes are CSRF-exempt because authentication is via Authorization header rather than Django session cookies.
- Mobile registration supports required ID document and profile photo uploads and creates the appropriate customer/rider/company profile.
- Rider registration remains pending until manager approval.
- Customer orders require valid latitude/longitude server-side.
- Rider delivery acceptance requires approved rider status and current GPS, with a configurable maximum distance check.
- Rider GPS is cleared after customer receipt confirmation.
- M-Pesa initiation does not equal payment completion; the Android app polls the server transaction status and only advances after verified PAID status.
- M-Pesa callbacks validate transaction amount and payer phone and are idempotent.
- Order totals consistently include the configured platform fee; the transaction uses the order fee snapshot, so changing the admin fee cannot retroactively change an existing order payment.
- Rider API responses hide exact delivery address/GPS until the rider has accepted the delivery; active rider GPS updates are rejected when there is no active delivery, and customer receipt clears the stored coordinates.
- Android CI now builds from the correct `android/` project directory and has a signed production AAB path requiring release secrets.
- Company API can transition PAID -> PREPARING -> READY.
- Android rider dashboard can refresh deliveries, require GPS, accept a delivery, and send rider location updates.
- Android tracking uses Google Maps Compose with rider/destination markers when a restricted Maps API key is configured.
- Android release logging is disabled and R8 shrinking is enabled.
- Android release builds require an explicit production API base URL and Maps API key.
- Retrofit/Gson DTOs are protected from R8 stripping.

## Verified in this workspace
- Python source compilation: PASS.
- Migration file syntax: PASS.
- Static API contract checks: PASS.
- ZIP/source packaging integrity: PASS.
- No provider credentials or production secrets are included in the release source.

## Not verifiable in this workspace
The environment does not contain the Android SDK/Gradle dependency cache or the Django runtime packages, so these cannot honestly be marked PASS here:
- Full `python manage.py check --deploy` against installed Django.
- Full Django test suite against PostgreSQL.
- Android Gradle compile / APK / AAB build.
- Physical Android GPS/permission testing.
- Google Maps runtime testing.
- Real Safaricom Daraja sandbox/production callbacks and B2C payouts.
- Real email/SMS provider delivery.
- HostPinnacle DNS/SSL/process configuration.
- Android release signing and Play Console validation.

## Required before commercial launch
1. Configure HostPinnacle HTTPS domain and PostgreSQL.
2. Configure production `.env` values and exact `DJANGO_ALLOWED_HOSTS`.
3. Run migrations, collectstatic, `check --deploy`, and the full test suite.
4. Build a release AAB with:
   `gradle assembleRelease -PAPI_BASE_URL=https://YOUR-DOMAIN/ -PMAPS_API_KEY=YOUR_RESTRICTED_MAPS_KEY`
5. Sign the AAB with your release/Play App Signing configuration.
6. Configure Safaricom Daraja production credentials and HTTPS callback URLs.
7. Test M-Pesa STK success, cancellation, timeout, duplicate callback, wrong amount, and wrong payer phone cases.
8. Test rider approval, GPS acceptance, live location, delivery completion, receipt confirmation, and coordinate clearing on a physical device.
9. Test company PAID -> PREPARING -> READY workflow and rider pickup.
10. Review Privacy Policy, Terms, Refund/Dispute, data retention, payment/escrow obligations, and Kenyan regulatory requirements with the business/legal team.

## Release conclusion
**Source-level production hardened: YES — after this audit/fix pass.**

**Verified production deployment: NOT YET.**

The second status is intentionally not marked complete until the real HostPinnacle environment, Android build, provider callbacks, and end-to-end device tests have been executed.
