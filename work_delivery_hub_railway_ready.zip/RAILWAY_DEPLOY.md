# Railway deployment — Work & Delivery Hub

This release is prepared for Railway staging. The Django backend is under `/backend`; the repository root contains `railway.toml`.

## 1. Create Railway project

1. Create a new Railway project.
2. Add a **PostgreSQL** service.
3. Add the GitHub repository as a service.
4. Generate a public HTTPS domain under the web service Networking settings.

Railway provides the PostgreSQL `DATABASE_URL`; reference it from the Django service as `\${{Postgres.DATABASE_URL}}` (adjust the service name if your Postgres service has a different name).

## 2. Variables

Copy the names from `backend/.env.railway.example` into the Railway service Variables tab. Replace placeholders with real staging values.

Required before deployment:
- `DJANGO_SECRET_KEY`
- `DJANGO_DEBUG=False`
- `DJANGO_ALLOWED_HOSTS` containing your Railway domain and `healthcheck.railway.app`
- `CSRF_TRUSTED_ORIGINS` containing the HTTPS Railway domain
- `DATABASE_URL` referencing Railway Postgres

For payment testing use **M-Pesa Daraja sandbox** credentials. Do not put live credentials in this staging project.

## 3. Deploy

The included Dockerfile installs dependencies, collects static assets, runs migrations at startup, and starts Gunicorn on Railway's injected `PORT`.

The Railway healthcheck is:

`GET /health/`

## 4. Verify

After deployment open:

- `https://YOUR-RAILWAY-DOMAIN/health/`
- `https://YOUR-RAILWAY-DOMAIN/`
- `https://YOUR-RAILWAY-DOMAIN/admin/`

Create a superuser from Railway's shell:

`python manage.py createsuperuser`

## 5. Media uploads

This app stores uploaded identity documents, profile photos, and food images under `/app/media`. Railway's container filesystem is not a substitute for durable object storage. For staging, attach a Railway Volume mounted at `/app/media` if you need uploads to survive redeploys. For commercial production, plan an object-storage/CDN migration for user uploads rather than relying on a local container filesystem.

## 6. Android staging

Set the Android app's API base URL to the Railway HTTPS domain, then build a staging APK/AAB. Test on real Android devices for GPS, maps, authentication, rider tracking, payments, and notifications.

## 7. Important staging scope

- Use PostgreSQL, not SQLite.
- Use Daraja sandbox, not live M-Pesa.
- Keep PayPal disabled unless its supported presentment currency and complete sandbox configuration are intentionally tested.
- Do not upload `.env`, credentials, keystores, or private keys to GitHub.
