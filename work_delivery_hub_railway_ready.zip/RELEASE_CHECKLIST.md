# Work & Delivery Hub — Release Checklist

## Before HostPinnacle launch
- [ ] Domain DNS points to HostPinnacle
- [ ] HTTPS/SSL active for the production domain
- [ ] PostgreSQL database/user created
- [ ] Production `.env` configured; no secrets committed
- [ ] `python manage.py migrate`
- [ ] `python manage.py collectstatic --noinput`
- [ ] `python manage.py check --deploy`
- [ ] `python manage.py test`
- [ ] `/health/` returns database `ok`
- [ ] Gunicorn/Passenger application is serving Django
- [ ] Protected identity/submission files cannot be downloaded directly

## Android release
- [ ] Set `API_BASE_URL` to the real HTTPS domain
- [ ] Set a restricted Google Maps API key
- [ ] Build release AAB with R8 enabled
- [ ] Sign with production/Play App Signing credentials
- [ ] Install and test on physical Android device

## End-to-end commercial test
- [ ] Customer registration with ID + profile photo
- [ ] Customer login
- [ ] Approved company visible
- [ ] Menu and quantities
- [ ] Mandatory GPS captured
- [ ] Order total includes 5% platform fee
- [ ] M-Pesa STK request
- [ ] Payment advances only after verified callback/status
- [ ] Company sees PAID order
- [ ] Company marks PREPARING
- [ ] Company marks READY
- [ ] Approved rider must have GPS
- [ ] Rider accepts nearby READY order
- [ ] Customer receives pickup notification
- [ ] Rider location updates appear on tracking map
- [ ] Rider marks delivery DELIVERED
- [ ] Customer marks RECEIVED
- [ ] Rider live coordinates are cleared
- [ ] Customer can rate rider/company once
- [ ] Job posting/bidding/payment/submission/review workflow tested
- [ ] M-Pesa duplicate/wrong amount/wrong phone cases tested
- [ ] Backup and restore tested

## Final status
The source is production-hardened, but commercial launch is not complete until the real infrastructure, credentials, Android build, and end-to-end tests above have passed.
