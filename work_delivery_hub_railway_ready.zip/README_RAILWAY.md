# Railway-ready release

Deploy the repository root to Railway. Railway configuration is in `railway.toml`; the Django Dockerfile is `backend/Dockerfile`.

The backend is intentionally configured as a staging deployment: PostgreSQL is required when `DJANGO_DEBUG=False`, migrations run before Gunicorn starts, and `/health/` is configured for Railway deployment health checks.

See `RAILWAY_DEPLOY.md` for the deployment steps and `backend/.env.railway.example` for the required variable names.
